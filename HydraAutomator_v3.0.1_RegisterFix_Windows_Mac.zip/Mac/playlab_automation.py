import csv
import os
import queue
import random
import re
import string
import sys
import json
import platform
import shutil
from urllib.parse import urlparse
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk


def configure_dpi_awareness():
    """Make the Tk window render at native DPI on Windows instead of being bitmap-scaled."""
    if platform.system() != "Windows":
        return
    try:
        import ctypes
        # Windows 10 1703+: per-monitor-v2 awareness.
        if hasattr(ctypes, "windll"):
            user32 = ctypes.windll.user32
            try:
                user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
                return
            except Exception:
                pass
            # Windows 8.1 fallback: per-monitor DPI awareness.
            try:
                ctypes.windll.shcore.SetProcessDpiAwareness(2)
            except Exception:
                pass
    except Exception:
        pass


configure_dpi_awareness()

from playwright.sync_api import sync_playwright

# A packaged (.exe) app has no console, so give the print streams somewhere to go.
if sys.stdout is None:
    sys.stdout = open(os.devnull, "w")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w")

# ---------------------------------------------------------------------------
# App identity  (change LEAD_DEVELOPER to your name)
# ---------------------------------------------------------------------------
APP_NAME = "Hydra Automator"
APP_VERSION = "3.0.1"
LEAD_DEVELOPER = "Your Name"

# Default target: the safe practice site.
DEFAULT_URL = "https://playwrightlab.github.io/"
TEST_DOMAIN = "example.test"
MAX_ACCOUNTS = 10
FAKE_NAMES = [
    "Alex Smith", "Jordan Lee", "Sam Brown",
    "Taylor Miller", "Chris Wilson", "Drew Davis"
]
EMAIL_FINDER = re.compile(r"[^@\s,;]+@[^@\s,;]+\.[^@\s,;]+")

if getattr(sys, "frozen", False):
    APP_DIR = os.path.dirname(sys.executable)
else:
    APP_DIR = os.path.dirname(os.path.abspath(__file__))

def user_data_dir():
    system = platform.system()
    if system == "Windows":
        base = os.environ.get("APPDATA") or os.path.expanduser("~\\AppData\\Roaming")
    elif system == "Darwin":
        base = os.path.expanduser("~/Library/Application Support")
    else:
        base = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
    path = os.path.join(base, "Hydra Automator")
    os.makedirs(path, exist_ok=True)
    return path

APP_DATA_DIR = user_data_dir()
SCREENSHOT_DIR = os.path.join(APP_DATA_DIR, "screenshots")
RESULTS_DIR = os.path.join(APP_DATA_DIR, "results")
SETTINGS_FILE = os.path.join(APP_DATA_DIR, "hydra_settings.json")

# ---------------------------------------------------------------------------
# Look and feel
# ---------------------------------------------------------------------------
UI_FONT = "Segoe UI"
MONO_FONT = "Consolas"

BG = "#0f1318"            # window
PANEL = "#171c23"         # panels
PANEL_ALT = "#1b212a"     # zebra rows
HEADER_BG = "#1e2530"     # table header
INPUT_BG = "#11161c"
LOG_BG = "#0c1015"
BORDER = "#2a323d"
BORDER_LIGHT = "#3a4453"

TEXT = "#e4e8ee"
MUTED = "#8a94a3"

ACCENT_BLUE = "#4c8dff"   # focus rings
BLUE_INFO = "#79b8ff"
GREEN_TEXT = "#5fd39a"
GREEN_FILL = "#2a9d6f"    # primary action
GREEN_HOVER = "#33b07d"
AMBER = "#e3b341"
RED = "#e57373"
RED_BORDER = "#6b3a40"
RED_HOVER = "#2b1f24"
BTN_BG = "#232a35"
BTN_HOVER = "#2d3644"

# Result badges: (text color, background color)
BADGES = {
    "PASS": (GREEN_TEXT, "#13332a"),
    "FAIL": ("#f08c8c", "#3a1d22"),
    "CHECK": (AMBER, "#3a2f14"),
    "CAPTCHA": (AMBER, "#3a2f14"),
    "NO FORM": (AMBER, "#3a2f14"),
    "STOPPED": (AMBER, "#3a2f14"),
    "RUNNING": (BLUE_INFO, "#152a44"),
}
DEFAULT_BADGE = (MUTED, "#232a35")

# Only these kinds of files inside the app's own folders are ever deleted.
SAVED_DIRS = [(SCREENSHOT_DIR, (".png",)), (RESULTS_DIR, (".csv",))]


def apply_badge(label, text):
    fg, bg = BADGES.get(text, DEFAULT_BADGE)
    label.config(text=text, fg=fg, bg=bg)


def status_color(text):
    """Pick the dot color for the status badge."""
    t = text.upper()
    if "ERROR" in t:
        return RED
    if any(word in t for word in ("STOPPED", "TICK", "PERMISSION")):
        return AMBER
    if any(word in t for word in ("ALL DONE", "RECORD(S) READY")):
        return GREEN_TEXT
    if any(word in t for word in ("ACCOUNT", "STARTING", "LAUNCH")):
        return BLUE_INFO
    return MUTED


def classify_log(message):
    """Decide the color of a log line: warn (amber), err, ok (green) or info."""
    text = message.lower()
    if any(word in text for word in (
        "captcha", "stopped", "stopping", "heads up", "couldn't tell",
        "limit is", "blocked", "wait for it", "tick the", "nothing is running",
        "nothing to", "already running", "no browser", "no email address found",
        "same email as", "you entered"
    )):
        return "warn"
    if any(word in text for word in (
        "error", "problem", "couldn't", "failed", "can't"
    )):
        return "err"
    if any(word in text for word in (
        "saved", "loaded", "built", "all done", "looks like it worked",
        "success", "cleared", "deleted", "system online", "browser closed"
    )):
        return "ok"
    return "info"


def list_saved_files():
    """Files the app itself saved (screenshots and result sheets)."""
    found = []
    for folder, extensions in SAVED_DIRS:
        if not os.path.isdir(folder):
            continue
        for name in os.listdir(folder):
            path = os.path.join(folder, name)
            if os.path.isfile(path) and name.lower().endswith(extensions):
                found.append(path)
    return found


def _browser_candidates():
    """Return detected browsers plus Playwright-managed engines."""
    system = platform.system()
    candidates = []

    def add(label, engine, path=None, channel=None, detected=True, launchable=True):
        candidates.append({
            "label": label, "engine": engine, "path": path,
            "channel": channel, "detected": detected, "launchable": launchable,
        })

    # Playwright-managed engines are real selectable choices.  Chromium is
    # intentionally always listed; launch_browser will give a precise message
    # if the bundled binary has not been installed yet.
    add("Playwright Chromium", "chromium", detected=False)
    add("Playwright Firefox", "firefox", detected=False)
    add("Playwright WebKit", "webkit", detected=False)

    if system == "Windows":
        local = os.environ.get("LOCALAPPDATA", "")
        pf = os.environ.get("PROGRAMFILES", "")
        pfx86 = os.environ.get("PROGRAMFILES(X86)", "")
        paths = [
            ("Microsoft Edge", "chromium", os.path.join(pf, "Microsoft", "Edge", "Application", "msedge.exe")),
            ("Microsoft Edge", "chromium", os.path.join(pfx86, "Microsoft", "Edge", "Application", "msedge.exe")),
            ("Google Chrome", "chromium", os.path.join(pf, "Google", "Chrome", "Application", "chrome.exe")),
            ("Google Chrome", "chromium", os.path.join(pfx86, "Google", "Chrome", "Application", "chrome.exe")),
            ("Google Chrome", "chromium", os.path.join(local, "Google", "Chrome", "Application", "chrome.exe")),
            ("Brave", "chromium", os.path.join(local, "BraveSoftware", "Brave-Browser", "Application", "brave.exe")),
            ("Opera", "chromium", os.path.join(local, "Programs", "Opera", "opera.exe")),
            ("Opera GX", "chromium", os.path.join(local, "Programs", "Opera GX", "opera.exe")),
            ("Vivaldi", "chromium", os.path.join(local, "Vivaldi", "Application", "vivaldi.exe")),
            ("Arc", "chromium", os.path.join(local, "Programs", "Arc", "Arc.exe")),
            ("Thorium", "chromium", os.path.join(local, "Thorium", "Application", "thorium.exe")),
            ("Chromium", "chromium", os.path.join(pf, "Chromium", "Application", "chrome.exe")),
            ("Chromium", "chromium", os.path.join(pfx86, "Chromium", "Application", "chrome.exe")),
            ("Firefox (installed)", "firefox", os.path.join(pf, "Mozilla Firefox", "firefox.exe"), False),
            ("Firefox (installed)", "firefox", os.path.join(pfx86, "Mozilla Firefox", "firefox.exe"), False),
        ]
    elif system == "Darwin":
        paths = [
            ("Microsoft Edge", "chromium", "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"),
            ("Google Chrome", "chromium", "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
            ("Brave", "chromium", "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser"),
            ("Opera", "chromium", "/Applications/Opera.app/Contents/MacOS/Opera"),
            ("Opera GX", "chromium", "/Applications/Opera GX.app/Contents/MacOS/Opera GX"),
            ("Vivaldi", "chromium", "/Applications/Vivaldi.app/Contents/MacOS/Vivaldi"),
            ("Arc", "chromium", "/Applications/Arc.app/Contents/MacOS/Arc"),
            ("Thorium", "chromium", "/Applications/Thorium.app/Contents/MacOS/Thorium"),
            ("Chromium", "chromium", "/Applications/Chromium.app/Contents/MacOS/Chromium"),
            ("Firefox (installed)", "firefox", "/Applications/Firefox.app/Contents/MacOS/firefox", False),
        ]
    else:
        paths = [
            ("Brave", "chromium", "/usr/bin/brave-browser"),
            ("Brave", "chromium", "/usr/bin/brave"),
            ("Opera", "chromium", "/usr/bin/opera"),
            ("Vivaldi", "chromium", "/usr/bin/vivaldi"),
            ("Arc", "chromium", "/usr/bin/arc"),
            ("Thorium", "chromium", "/usr/bin/thorium"),
            ("Chromium", "chromium", "/usr/bin/chromium"),
            ("Chromium", "chromium", "/usr/bin/chromium-browser"),
            ("Firefox (installed)", "firefox", "/usr/bin/firefox", False),
        ]

    for entry in paths:
        label, engine, path, *rest = entry
        if path and os.path.isfile(path):
            # Branded Firefox is deliberately detected but not marked launchable:
            # Playwright requires its patched Firefox build.
            launchable = rest[0] if rest else True
            add(label, engine, path=path, launchable=launchable)

    path_names = {
        "Google Chrome": ["google-chrome", "google-chrome-stable", "chrome", "chrome.exe"],
        "Microsoft Edge": ["msedge", "msedge.exe"],
        "Brave": ["brave", "brave-browser", "brave.exe"],
        "Opera": ["opera", "opera.exe"],
        "Opera GX": ["opera-gx", "opera_gx", "opera-gx.exe"],
        "Vivaldi": ["vivaldi", "vivaldi-stable", "vivaldi.exe"],
        "Arc": ["arc", "arc.exe"],
        "Thorium": ["thorium", "thorium.exe"],
        "Chromium": ["chromium", "chromium-browser", "chromium.exe"],
    }
    for label, names in path_names.items():
        found = next((shutil.which(n) for n in names if shutil.which(n)), None)
        if found:
            add(label, "chromium", path=found)

    ff = shutil.which("firefox") or shutil.which("firefox.exe")
    if ff:
        add("Firefox (installed)", "firefox", path=ff, launchable=False)

    if system == "Darwin" and os.path.exists("/Applications/Safari.app"):
        add("Safari (detected; use WebKit)", "webkit", detected=True, launchable=False)

    return candidates


def browser_inventory():
    """Return a de-duplicated browser inventory for the UI."""
    seen = set()
    out = []
    for item in _browser_candidates():
        key = (item["label"], item.get("path"), item.get("channel"))
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def _bundled_browser_root():
    # In source mode, PLAYWRIGHT_BROWSERS_PATH=0 puts browsers beside the
    # installed Playwright package. In frozen mode, the build copies them into
    # the executable's _MEIPASS directory.
    if getattr(sys, "frozen", False):
        root = getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
        candidate = os.path.join(root, "ms-playwright")
        return candidate if os.path.isdir(candidate) else None
    return None


def launch_browser(playwright, log, preferred="Auto", headless=False):
    """Launch a selected browser with robust Playwright/browser fallback."""
    bundled = _bundled_browser_root()
    if bundled:
        os.environ["PLAYWRIGHT_BROWSERS_PATH"] = bundled

    items = browser_inventory()
    if preferred and preferred != "Auto":
        preferred_items = [x for x in items if x["label"] == preferred and x["launchable"]]
        if not preferred_items:
            # Treat installed-browser display labels as a family choice.
            preferred_items = [x for x in items if x["label"].startswith(preferred) and x["launchable"]]
        ordered = preferred_items + [x for x in items if x not in preferred_items and x["launchable"]]
    else:
        # Prefer bundled Playwright Chromium first for reliability, then common
        # installed Chromium browsers, then Playwright Firefox/WebKit.
        priority = {
            "Playwright Chromium": 0, "Google Chrome": 1, "Microsoft Edge": 2,
            "Brave": 3, "Opera": 4, "Opera GX": 5, "Vivaldi": 6, "Arc": 7, "Thorium": 8,
            "Chromium": 9, "Playwright Firefox": 8, "Playwright WebKit": 9,
        }
        ordered = sorted([x for x in items if x["launchable"]], key=lambda x: priority.get(x["label"], 20))

    errors = []
    for item in ordered:
        try:
            launcher = getattr(playwright, item["engine"])
            options = {"headless": headless}
            if item.get("path"):
                options["executable_path"] = item["path"]
            browser = launcher.launch(**options)
            log(f"Using {item['label']}.")
            return browser, item["label"]
        except Exception as exc:
            errors.append(f"{item['label']}: {short(exc)}")
            continue

    raise RuntimeError(
        "Could not launch a browser. Select Playwright Chromium in Settings and "
        "run the browser installer/build script, or select an installed Chrome/Edge/"
        "Brave/Opera/Vivaldi browser.\n\n" + "\n".join(errors[:5])
    )


# ---------------------------------------------------------------------------
# Form-handling helpers (no window code in here)
# ---------------------------------------------------------------------------

CAPTCHA_SELECTOR = (
    'iframe[src*="recaptcha"], iframe[src*="hcaptcha"], '
    'iframe[src*="challenges.cloudflare.com"], '
    ".g-recaptcha, .h-captcha, .cf-turnstile"
)

# Looks at every visible box on the page and reports what it seems to be for.
FIELD_SCRIPT = """
() => {
  const out = [];
  const elements = Array.from(document.querySelectorAll('input, textarea, select'));
  const skip = ['hidden','submit','button','image','reset','file','radio','range','color'];
  let i = 0;
  for (const el of elements) {
    const type = (el.getAttribute('type') || el.tagName || 'text').toLowerCase();
    if (el.tagName === 'INPUT' && skip.includes(type)) continue;
    const r = el.getBoundingClientRect();
    const style = window.getComputedStyle(el);
    if (r.width === 0 || r.height === 0 ||
        style.visibility === 'hidden' || style.display === 'none') continue;
    let label = '';
    if (el.labels && el.labels.length) {
      label = Array.from(el.labels).map(l => l.innerText).join(' ');
    }
    let nearby = '';
    const parent = el.closest('label, fieldset, div, section');
    if (parent) nearby = (parent.innerText || '').slice(0, 240);
    el.setAttribute('data-pl-idx', String(i));
    out.push({
      idx: i,
      tag: el.tagName.toLowerCase(),
      type: type,
      required: !!el.required || el.getAttribute('aria-required') === 'true',
      text: [el.name, el.id, el.placeholder, el.getAttribute('aria-label'),
             el.autocomplete, label, nearby].join(' ').toLowerCase()
    });
    i++;
  }
  return out;
}
"""

SOCIAL_WORDS = re.compile(
    r"google|facebook|apple|github|microsoft|twitter|linkedin|sso", re.I
)
ERROR_WORDS = re.compile(
    r"already (exists|registered|in use|taken)|is taken|invalid|failed|"
    r"try again|not valid|something went wrong|an error",
    re.I,
)
SECURITY_BLOCK_WORDS = re.compile(
    r"access denied|forbidden|too many requests|rate limit|rate-limited|"
    r"request blocked|request denied|security check|security challenge|"
    r"bot detected|automated traffic|suspicious (activity|request)|"
    r"temporarily blocked|unusual traffic|verify you are human",
    re.I,
)
SUCCESS_WORDS = re.compile(
    r"success|welcome|thank you|thanks for|registered|account (has been )?created|"
    r"check your (email|inbox)|verify your|verification|confirm your",
    re.I,
)


def classify_fields(fields):
    """Classify visible registration/login controls using human-facing hints."""
    found = {
        "emails": [], "passwords": [], "confirm_passwords": [], "boxes": [],
        "boxes_required": [], "boxes_optional": [], "boxes": [], "selects": [],
        "first": None, "last": None, "username": None, "fullname": None,
        "month": None, "day": None, "year": None, "dates": [],
    }
    for field in fields:
        kind = (field.get("type") or "text").lower()
        text = field.get("text", "")
        if field.get("tag") == "select":
            found["selects"].append(field)
        if kind == "password":
            if re.search(r"confirm|repeat|re[- ]?enter|again|verify", text):
                found["confirm_passwords"].append(field)
            else:
                found["passwords"].append(field)
        elif kind == "checkbox":
            found["boxes"].append(field)
            if field.get("required") or re.search(r"required|terms|agree|accept|privacy|policy|consent|legal", text):
                found["boxes_required"].append(field)
            else:
                found["boxes_optional"].append(field)
        elif kind == "email" or "email" in text or "e-mail" in text:
            found["emails"].append(field)
        elif kind == "date" or re.search(
            r"\b(date of birth|birth date|birthday|dob|birth month|birth day|birth year|month of birth|day of birth|year of birth)\b",
            text,
        ):
            found["dates"].append(field)
            if "month" in text and found["month"] is None: found["month"] = field
            elif "day" in text and found["day"] is None: found["day"] = field
            elif "year" in text and found["year"] is None: found["year"] = field
        elif re.search(r"\bfirst(?:\s+name)?\b|given(?:\s+name)?", text):
            found["first"] = found["first"] or field
        elif re.search(r"\blast(?:\s+name)?\b|family(?:\s+name)?|surname", text):
            found["last"] = found["last"] or field
        elif re.search(r"user(?:name)?|login|handle", text):
            found["username"] = found["username"] or field
        elif re.search(r"full\s*name|your\s*name|^name\b|\bname\b", text):
            found["fullname"] = found["fullname"] or field
    return found


def has_captcha(page):
    selectors = [
        'iframe[src*="recaptcha"]',
        'iframe[src*="hcaptcha"]',
        'iframe[src*="challenges.cloudflare.com"]',
        '.g-recaptcha', '.h-captcha', '.cf-turnstile',
        '[data-sitekey][data-callback]',
    ]
    for selector in selectors:
        try:
            loc = page.locator(selector)
            count = min(loc.count(), 20)
            for i in range(count):
                try:
                    if loc.nth(i).is_visible():
                        return True
                except Exception:
                    continue
        except Exception:
            continue
    return False


def settle(page):
    """Give the page a moment to finish loading."""
    try:
        page.wait_for_load_state("networkidle", timeout=5000)
    except Exception:
        pass
    page.wait_for_timeout(500)


def _field_locator(page, field):
    return page.locator(f'[data-pl-idx="{field["idx"]}"]').first


def _fill_or_select(page, field, value):
    loc = _field_locator(page, field)
    if field.get("tag") == "select":
        try:
            loc.select_option(label=value, timeout=3000)
            return
        except Exception:
            try:
                loc.select_option(value=value, timeout=3000)
                return
            except Exception:
                # Some date selects use numeric values while displaying names.
                loc.select_option(index=max(0, int(str(value)) - 1), timeout=3000)
                return
    loc.fill(value, timeout=5000)


def _dob_for_field(field, page):
    month = getattr(page, "_hydra_dob_month", "01")
    day = getattr(page, "_hydra_dob_day", "01")
    year = getattr(page, "_hydra_dob_year", "2000")
    text = field.get("text", "")
    if "month" in text:
        return month
    if "day" in text:
        return day
    if "year" in text:
        return year
    fmt = getattr(page, "_hydra_dob_format", "MM/DD/YYYY")
    if field.get("tag") == "select":
        return month if "month" in text else day if "day" in text else year
    if fmt == "DD/MM/YYYY":
        return f"{day}/{month}/{year}"
    if fmt == "YYYY-MM-DD":
        return f"{year}-{month}-{day}"
    return f"{month}/{day}/{year}"


def fill_generic_form(page, number, name, email, password, log):
    """Fill the currently visible registration step. Returns a field summary."""
    fields = page.evaluate(FIELD_SCRIPT)
    found = classify_fields(fields)

    if not found["emails"] and not found["username"]:
        log(f"[{number}] Couldn't find an email or username box on this step.")
        return False
    if not found["passwords"]:
        log(f"[{number}] Couldn't find a password box on this step.")
        return False

    parts = name.split(" ", 1)
    first_name = parts[0]
    last_name = parts[1] if len(parts) > 1 else parts[0]

    try:
        if found["fullname"]:
            log(f"[{number}] Filling name...")
            _fill_or_select(page, found["fullname"], name)
        if found["first"]:
            _fill_or_select(page, found["first"], first_name)
        if found["last"]:
            _fill_or_select(page, found["last"], last_name)
        if found["username"]:
            log(f"[{number}] Filling username...")
            _fill_or_select(page, found["username"], email.split("@")[0])

        log(f"[{number}] Filling email...")
        for field in found["emails"]:
            _fill_or_select(page, field, email)

        log(f"[{number}] Filling password...")
        for field in found["passwords"]:
            _fill_or_select(page, field, password)
        for field in found["confirm_passwords"]:
            log(f"[{number}] Confirming password...")
            _fill_or_select(page, field, password)

        for field in found["dates"]:
            try:
                _fill_or_select(page, field, _dob_for_field(field, page))
            except Exception:
                pass

        # Tick required agreement/legal boxes. We deliberately don't force optional marketing boxes.
        for box in found["boxes_required"]:
            try:
                _field_locator(page, box).check(timeout=2500, force=True)
            except Exception:
                pass
    except Exception as error:
        log(f"[{number}] Form fill problem: {short(error)}")
        return False
    return True


def _flow_phrases(flow):
    if flow == "login":
        return [
            r"\blog\s*in\b", r"\blogin\b", r"\bsign\s*in\b",
            r"member\s*login", r"account\s*login", r"access\s*account",
            r"continue\s*to\s*account",
        ]
    return [
        r"\bsign\s*up\b", r"\bsignup\b", r"\bregister\b",
        r"create\s+(?:an?\s+)?account", r"\bjoin\b(?:\s+(?:now|us))?",
        r"get\s*started", r"create\s*profile",
    ]


def _flow_candidates(page, flow):
    pattern = re.compile("|".join(_flow_phrases(flow)), re.I)
    selectors = ["button", "a", "input[type=submit]", "[role=button]"]
    candidates = []
    for selector in selectors:
        try:
            loc = page.locator(selector)
            count = min(loc.count(), 100)
        except Exception:
            continue
        for i in range(count):
            el = loc.nth(i)
            try:
                if not el.is_visible() or not el.is_enabled():
                    continue
                visible = (el.inner_text() or "").strip()
                aria = (el.get_attribute("aria-label") or "").strip()
                title = (el.get_attribute("title") or "").strip()
                name = (el.get_attribute("name") or "").strip()
                value = (el.get_attribute("value") or "").strip()
                ident = " ".join([el.get_attribute("id") or "", el.get_attribute("class") or ""]).strip()
                if SOCIAL_WORDS.search(" ".join([visible, aria, title, name, value, ident])):
                    continue

                # Score human-facing signals more heavily than implementation details.
                score = 0
                if pattern.search(visible):
                    score += 100
                if pattern.search(aria):
                    score += 90
                if pattern.search(title):
                    score += 60
                if pattern.search(name):
                    score += 35
                if pattern.search(value):
                    score += 75
                if pattern.search(ident):
                    score += 20

                label = visible or aria or title or value or name or ident
                if score >= 35:
                    candidates.append((score, label[:120], el))
            except Exception:
                continue
    candidates.sort(key=lambda item: item[0], reverse=True)
    return candidates


def detect_flow_elements(page, flow="signup"):
    """Return the strongest visible login/register candidates."""
    seen = set()
    hits = []
    for score, label, _ in _flow_candidates(page, flow):
        key = label.lower()
        if key in seen:
            continue
        seen.add(key)
        hits.append(label)
        if len(hits) >= 8:
            break
    return hits


def click_flow_entry(page, flow, number, log):
    """Click the strongest likely login/register control, then let the page settle."""
    candidates = _flow_candidates(page, flow)
    if not candidates:
        return False
    score, label, element = candidates[0]
    try:
        before_url = page.url
        log(f"[{number}] Detected {flow} control: '{label}'.")
        log(f"[{number}] Opening {flow} flow...")
        element.click(timeout=7000)
        try:
            page.wait_for_load_state("domcontentloaded", timeout=5000)
        except Exception:
            pass
        page.wait_for_timeout(500)
        if page.url != before_url:
            log(f"[{number}] Opened {page.url}")
        return True
    except Exception as error:
        log(f"[{number}] Couldn't open {flow} flow: {short(error)}")
        return False


def click_flow_button(page, flow, number, log):
    """Click a likely submit/continue control for login or registration."""
    phrases = (
        [r"sign\s*in", r"log\s*in", r"login", r"continue", r"next"]
        if flow == "login" else
        [r"sign\s*up", r"register", r"create.{0,16}account", r"create.{0,16}profile",
         r"join(?:\s+now)?", r"get started", r"continue", r"next", r"submit"]
    )

    controls = page.locator(
        'button:visible, input[type="submit"]:visible, [role="button"]:visible'
    )
    candidates = []
    for i in range(min(controls.count(), 100)):
        button = controls.nth(i)
        try:
            if not button.is_enabled():
                continue
            label = " ".join(filter(None, [
                button.inner_text(),
                button.get_attribute("aria-label"),
                button.get_attribute("title"),
                button.get_attribute("value"),
                button.get_attribute("name"),
            ])).strip()
            if not label or SOCIAL_WORDS.search(label):
                continue
            score = 0
            for rank, pattern in enumerate(phrases):
                if re.search(pattern, label, re.I):
                    score = max(score, 100 - rank * 5)
            if score:
                candidates.append((score, label[:100], button))
        except Exception:
            continue

    candidates.sort(key=lambda x: x[0], reverse=True)
    if not candidates:
        return False

    _, label, button = candidates[0]
    try:
        log(f"[{number}] Clicking '{label or 'button'}'...")
        button.click(timeout=7000)
        try:
            page.wait_for_load_state("domcontentloaded", timeout=5000)
        except Exception:
            pass
        page.wait_for_timeout(500)
        return True
    except Exception as error:
        log(f"[{number}] Couldn't click submit control: {short(error)}")
        return False


def login_account(page, number, email, password, log, should_stop=None):
    """Fill a generic login form for an authorized test site."""
    stop = should_stop or (lambda: False)
    settle(page)
    if stop():
        return "STOPPED"
    if has_captcha(page):
        log(f"[{number}] CAPTCHA found. Stopping - manual intervention required.")
        return "CAPTCHA"

    fields = page.evaluate(FIELD_SCRIPT)
    found = classify_fields(fields)
    if not found["passwords"]:
        if click_flow_entry(page, "login", number, log):
            try:
                page.wait_for_timeout(500)
                settle(page)
                fields = page.evaluate(FIELD_SCRIPT)
                found = classify_fields(fields)
            except Exception:
                pass
    if not found["passwords"]:
        log(f"[{number}] Couldn't find a password box for login.")
        return "NO FORM"

    def put(field, value):
        page.locator(f'[data-pl-idx="{field["idx"]}"]').fill(value, timeout=5000)

    if found["emails"]:
        put(found["emails"][0], email)
    elif found["username"]:
        put(found["username"], email.split("@")[0])
    else:
        log(f"[{number}] Couldn't find an email/username box for login.")
        return "NO FORM"
    put(found["passwords"][0], password)
    if stop():
        return "STOPPED"
    if not click_flow_button(page, "login", number, log):
        log(f"[{number}] No login button found, pressing Enter.")
        page.locator("input[type=password]:visible").first.press("Enter")
    return judge_result(page, number, log)


def click_submit(page, number, log):
    """Click the Register / Sign up button (skips 'Sign up with Google' etc.)."""
    password_box = page.locator("input[type=password]:visible").first
    scope = page
    try:
        form = password_box.locator("xpath=ancestor::form")
        if form.count() > 0:
            scope = form.first
    except Exception:
        pass

    patterns = [
        r"sign\s*up|signup|register|create.{0,12}account",
        r"join|get started|continue|next|submit",
    ]
    for pattern in patterns:
        buttons = scope.get_by_role("button", name=re.compile(pattern, re.I))
        for i in range(buttons.count()):
            button = buttons.nth(i)
            try:
                label = button.inner_text() or button.get_attribute("value") or ""
            except Exception:
                label = ""
            if SOCIAL_WORDS.search(label):
                continue
            log(f"[{number}] Clicking '{label.strip() or 'button'}'...")
            button.click(timeout=5000)
            return True

    log(f"[{number}] No button found, pressing Enter instead...")
    password_box.press("Enter")
    return True


def detect_security_block(page):
    """Return an objective security/challenge label from the current page.

    This only detects a defense signal; Hydra never attempts to bypass or evade it.
    """
    try:
        status = getattr(page, "_hydra_last_status", None)
        if status == 403:
            return "FORBIDDEN"
        if status == 429:
            return "RATE LIMITED"
        if status is not None and 400 <= status < 500:
            return f"HTTP {status}"
    except Exception:
        pass

    try:
        title = page.title() or ""
    except Exception:
        title = ""
    try:
        body = page.locator("body").inner_text(timeout=1500)
    except Exception:
        body = ""
    sample = f"{title} {body} {page.url}"
    if SECURITY_BLOCK_WORDS.search(sample):
        lowered = sample.lower()
        if "rate" in lowered or "too many requests" in lowered or "429" in lowered:
            return "RATE LIMITED"
        if "forbidden" in lowered or "access denied" in lowered or "403" in lowered:
            return "FORBIDDEN"
        return "SECURITY CHALLENGE"
    return None


def judge_result(page, number, log):
    """Look at the page after submitting and decide how it went."""
    try:
        page.wait_for_load_state("networkidle", timeout=6000)
    except Exception:
        pass
    page.wait_for_timeout(1000)

    security = detect_security_block(page)
    if security:
        log(f"[{number}] Security defense detected: {security}. Stopping for inspection.")
        return security

    if has_captcha(page):
        log(f"[{number}] A CAPTCHA showed up. Stopping - this tool doesn't solve those.")
        return "CAPTCHA"

    try:
        text = page.inner_text("body")
    except Exception:
        text = ""

    if ERROR_WORDS.search(text):
        log(f"[{number}] The site showed an error message.")
        return "FAIL"

    still_on_form = page.locator("input[type=password]:visible").count() > 0
    if not still_on_form:
        log(f"[{number}] The signup form is gone - looks like it worked.")
        return "PASS"
    if SUCCESS_WORDS.search(text):
        log(f"[{number}] The page shows a success message.")
        return "PASS"

    log(f"[{number}] Couldn't tell if it worked - check the browser.")
    return "CHECK"


def register_account(page, number, name, email, password, log, should_stop=None):
    """Run a robust, multi-step registration flow on an authorized test site."""
    stop = should_stop or (lambda: False)
    settle(page)
    if stop():
        return "STOPPED"

    if has_captcha(page):
        log(f"[{number}] CAPTCHA found on the page. Stopping - this tool doesn't solve those.")
        return "CAPTCHA"

    # Up to three visible registration steps: sign-up page -> profile/DOB -> final submit.
    # We never attempt to bypass a security challenge; we only inspect and fill ordinary form controls.
    opened_flow = False
    for step in range(3):
        if stop():
            return "STOPPED"
        if has_captcha(page):
            log(f"[{number}] CAPTCHA appeared. Stopping - manual intervention required.")
            return "CAPTCHA"

        fields = page.evaluate(FIELD_SCRIPT)
        found = classify_fields(fields)
        has_form = bool(
            found["passwords"] or found["emails"] or found["username"] or
            found["fullname"] or found["first"] or found["last"] or
            found["dates"] or found["selects"] or found["boxes"]
        )

        if not has_form and not opened_flow:
            if click_flow_entry(page, "signup", number, log):
                opened_flow = True
                try:
                    settle(page)
                except Exception:
                    pass
                continue

        if not has_form:
            # Some sites expose a registration modal only after a short client-side delay.
            try:
                page.wait_for_timeout(700)
                fields = page.evaluate(FIELD_SCRIPT)
                found = classify_fields(fields)
                has_form = bool(
            found["passwords"] or found["emails"] or found["username"] or
            found["fullname"] or found["first"] or found["last"] or
            found["dates"] or found["selects"] or found["boxes"]
        )
            except Exception:
                pass

        if has_form:
            log(f"[{number}] Registration step {step + 1}: filling visible fields...")
            if not fill_generic_form(page, number, name, email, password, log):
                return "NO FORM"

        if stop():
            return "STOPPED"
        if has_captcha(page):
            log(f"[{number}] CAPTCHA appeared. Stopping - this tool doesn't solve those.")
            return "CAPTCHA"

        # First try the strongest submit/continue control. If it changes the DOM into
        # another registration step, the loop rescans rather than reusing stale locators.
        if click_flow_button(page, "signup", number, log):
            opened_flow = True
            settle(page)
            security = detect_security_block(page)
            if security:
                log(f"[{number}] Security defense detected: {security}.")
                return security

            # Determine whether registration is still active after the click.
            try:
                after = classify_fields(page.evaluate(FIELD_SCRIPT))
                if (after["passwords"] or after["emails"] or after["username"] or
                    after["fullname"] or after["first"] or after["last"] or
                    after["dates"] or after["selects"] or after["boxes"]):
                    # A second step remains; continue the loop.
                    if step < 2:
                        continue
            except Exception:
                pass
        break

    return judge_result(page, number, log)


def normalize_url(raw):
    raw = raw.strip()
    if not raw:
        return None

    candidate = raw if re.match(r"^https?://", raw, re.I) else None
    if candidate is None:
        if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", raw):
            return None
        local = re.match(
            r"^(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)",
            raw, re.I,
        )
        candidate = ("http://" if local else "https://") + raw

    parsed = urlparse(candidate)
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.netloc:
        return None
    return candidate


def make_password():
    return (
        "Test!"
        + "".join(random.choices(string.ascii_letters + string.digits, k=8))
        + random.choice(string.digits)
        + random.choice(string.ascii_lowercase)
    )


def parse_account_list(text):
    """Turn the notepad text into accounts.

    Each line can be name + email, e.g.  Alex Smith, alex@mysite.com
    or name + email + password for authorized login tests. A line with only
    an email also works. Returns (accounts, problems).
    """
    lines = [line.strip() for line in text.splitlines() if line.strip()]

    if len(lines) > MAX_ACCOUNTS:
        return [], [
            f"You entered {len(lines)} lines. The limit is {MAX_ACCOUNTS}."
        ]

    accounts, problems, seen = [], [], {}
    for number, line in enumerate(lines, start=1):
        match = EMAIL_FINDER.search(line)
        if not match:
            problems.append(f"Line {number}: no email address found.")
            continue

        email = match.group(0)
        key = email.lower()
        if key in seen:
            problems.append(
                f"Line {number}: same email as line {seen[key]}."
            )
            continue
        seen[key] = number

        remainder = line.replace(email, " ", 1)
        password_match = re.search(r"(?:^|[,;\t|:])\s*([^,;\t|: ]{6,})\s*$", remainder)
        supplied_password = password_match.group(1) if password_match and password_match.group(1) else None
        if supplied_password and supplied_password.lower() not in {"password", "pass"}:
            name_part = remainder[:password_match.start()]
        else:
            name_part = remainder
        name_part = re.sub(r"[,;\t]+", " ", name_part).strip(" -:|")
        name = " ".join(name_part.split()) or random.choice(FAKE_NAMES)
        accounts.append((name, email, supplied_password or make_password()))

    return accounts, problems


def short(error):
    lines = str(error).strip().splitlines()
    return (lines[0] if lines else "unknown error")[:200]


# ---------------------------------------------------------------------------
# The app window
# ---------------------------------------------------------------------------

class CheckBox(tk.Frame):
    """A dark-theme check box with a clear tick mark."""

    def __init__(self, parent, text, command=None, value=False):
        super().__init__(parent, bg=PANEL, cursor="hand2")
        self.value = bool(value)
        self.command = command

        self.box = tk.Canvas(
            self, width=18, height=18, bg=PANEL,
            highlightthickness=0, cursor="hand2"
        )
        self.box.pack(side="left")
        self.caption = tk.Label(
            self, text=text, bg=PANEL, fg=TEXT,
            font=(UI_FONT, 10), cursor="hand2"
        )
        self.caption.pack(side="left", padx=(8, 0))

        for widget in (self, self.box, self.caption):
            widget.bind("<Button-1>", self.toggle)
        self.draw()

    def draw(self):
        self.box.delete("all")
        if self.value:
            self.box.create_rectangle(
                1, 1, 17, 17, fill=GREEN_FILL, outline=GREEN_FILL
            )
            self.box.create_line(4, 9, 8, 13, 14, 5, fill="white", width=2)
        else:
            self.box.create_rectangle(
                1, 1, 17, 17, fill=INPUT_BG, outline=BORDER_LIGHT
            )

    def toggle(self, _event=None):
        self.set(not self.value)
        if self.command:
            self.command()

    def set(self, value):
        self.value = bool(value)
        self.draw()

    def get(self):
        return self.value


class AutomationApp:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_NAME)
        self.root.geometry("1000x780")
        self.root.minsize(1000, 700)
        self.root.configure(bg=BG)

        self.rows = []
        self.running = False
        self.test_mode = True
        self.permission_ok = False
        self.current_page = None
        self.ui_queue = queue.Queue()
        self.active_run = None
        self.run_lock = threading.Lock()
        self.settings = self.load_settings()
        self.operation_mode = self.settings.get("operation_mode", "Sign Up / Register")
        self.preferred_browser = self.settings.get("browser", "Auto")
        self.delay_seconds = float(self.settings.get("delay_seconds", 1.0))
        self.headless = bool(self.settings.get("headless", False))
        self.keep_browser_open = bool(self.settings.get("keep_browser_open", True))
        self.screenshot_on_issue = bool(self.settings.get("screenshot_on_issue", True))
        self.dob_month = str(self.settings.get("dob_month", "01"))
        self.dob_day = str(self.settings.get("dob_day", "01"))
        self.dob_year = str(self.settings.get("dob_year", "2000"))
        self.dob_format = self.settings.get("dob_format", "MM/DD/YYYY")
        self.browser_sessions = []

        self.setup_styles()

        self.outer = tk.Frame(root, bg=BG)
        self.outer.pack(fill="both", expand=True, padx=16, pady=(14, 10))

        # Order matters: top panels first, bottom panels next, table fills the rest.
        self.build_header()
        self.build_config()
        self.build_toolbar()
        self.build_footer()
        self.build_log()
        self.build_table()

        self.log_message("System online.")
        self.log_message("Test mode is on: fake @example.test addresses only.")
        self.log_message("Max 10 accounts per run.")
        self.log_message("Tick the permission box, then GENERATE and START TEST.")
        self.update_test_mode_ui()
        self.show_status("READY")

        self.root.after(100, self.process_queue)
        self.root.after(700, self.refresh_browser_summary)
        # Show the startup overlay only after the main UI exists, so the overlay
        # is the topmost Tk sibling instead of being covered by the UI frames.
        self.root.after(20, self.show_startup_screen)

    # ----- building blocks -----

    def setup_styles(self):
        try:
            style = ttk.Style()
            style.theme_use("clam")
            style.configure(
                "Dark.Vertical.TScrollbar",
                background=BORDER_LIGHT, troughcolor=PANEL,
                bordercolor=PANEL, lightcolor=BORDER_LIGHT,
                darkcolor=BORDER_LIGHT, arrowcolor=MUTED, relief="flat"
            )
            style.map(
                "Dark.Vertical.TScrollbar",
                background=[("active", MUTED)]
            )
        except Exception:
            pass

    def make_panel(self, side="top", fill="x", expand=False, pady=(0, 10)):
        shell = tk.Frame(
            self.outer, bg=PANEL, highlightthickness=1,
            highlightbackground=BORDER, highlightcolor=BORDER
        )
        shell.pack(side=side, fill=fill, expand=expand, pady=pady)
        inner = tk.Frame(shell, bg=PANEL)
        inner.pack(fill="both", expand=True, padx=14, pady=12)
        return inner

    def section_title(self, parent, text, hint=""):
        row = tk.Frame(parent, bg=PANEL)
        row.pack(fill="x")
        tk.Label(
            row, text=text, bg=PANEL, fg=MUTED, font=(UI_FONT, 9, "bold")
        ).pack(side="left")
        if hint:
            tk.Label(
                row, text=hint, bg=PANEL, fg=MUTED, font=(UI_FONT, 9)
            ).pack(side="left", padx=10)
        return row

    def make_button(self, parent, text, command, kind="secondary", small=False):
        styles = {
            "primary": ("#ffffff", GREEN_FILL, GREEN_HOVER, GREEN_FILL),
            "secondary": (TEXT, BTN_BG, BTN_HOVER, BORDER_LIGHT),
            "danger": (RED, PANEL, RED_HOVER, RED_BORDER),
        }
        fg, bg, hover, border = styles[kind]
        button = tk.Button(
            parent, text=text, command=command,
            fg=fg, bg=bg, activeforeground=fg, activebackground=hover,
            relief="flat", bd=0, cursor="hand2",
            highlightthickness=1, highlightbackground=border,
            highlightcolor=border,
            font=(UI_FONT, 8 if small else 9, "bold"),
            padx=10 if small else 12, pady=3 if small else 6
        )
        button.bind("<Enter>", lambda _e: button.config(bg=hover))
        button.bind("<Leave>", lambda _e: button.config(bg=bg))
        return button

    def make_entry(self, parent, variable):
        return tk.Entry(
            parent, textvariable=variable,
            fg=TEXT, bg=INPUT_BG, insertbackground=TEXT,
            relief="flat", bd=8, font=(MONO_FONT, 10),
            highlightthickness=1, highlightbackground=BORDER_LIGHT,
            highlightcolor=ACCENT_BLUE
        )

    def divider(self, parent):
        tk.Frame(parent, bg=BORDER, width=1, height=26).pack(
            side="left", padx=10
        )

    # ----- the five sections -----

    def build_header(self):
        inner = self.make_panel()

        titles = tk.Frame(inner, bg=PANEL)
        titles.pack(side="left")
        tk.Label(
            titles, text=APP_NAME, bg=PANEL, fg=TEXT,
            font=(UI_FONT, 18, "bold")
        ).pack(anchor="w")
        tk.Label(
            titles,
            text="Account automation workspace  -  for sites you own or have permission to test",
            bg=PANEL, fg=MUTED, font=(UI_FONT, 9)
        ).pack(anchor="w")

        head_actions = tk.Frame(inner, bg=PANEL)
        head_actions.pack(side="right", anchor="n", padx=(10, 0))
        self.make_button(head_actions, "⚙ SETTINGS", self.open_settings, small=True).pack(side="left", padx=3)
        self.make_button(head_actions, "ℹ CREDITS", self.open_credits, small=True).pack(side="left", padx=3)

        self.badge = tk.Frame(
            inner, bg=INPUT_BG, highlightthickness=1,
            highlightbackground=BORDER_LIGHT
        )
        self.badge.pack(side="right", anchor="n")
        self.badge_dot = tk.Label(
            self.badge, text="\u25cf", bg=INPUT_BG, fg=MUTED,
            font=(UI_FONT, 10)
        )
        self.badge_dot.pack(side="left", padx=(10, 4), pady=4)
        self.badge_text = tk.Label(
            self.badge, text="READY", bg=INPUT_BG, fg=TEXT,
            font=(UI_FONT, 9, "bold")
        )
        self.badge_text.pack(side="left", padx=(0, 12), pady=4)

    def build_config(self):
        inner = self.make_panel()
        self.section_title(inner, "CONFIGURATION")

        mode_row = tk.Frame(inner, bg=PANEL)
        mode_row.pack(fill="x", pady=(10, 0))
        tk.Label(mode_row, text="Operation", bg=PANEL, fg=TEXT, font=(UI_FONT, 10)).pack(side="left")
        self.mode_combo = ttk.Combobox(
            mode_row, state="readonly", width=22,
            values=["Sign Up / Register", "Login / Sign In"],
        )
        self.mode_combo.set(self.operation_mode)
        self.mode_combo.pack(side="left", padx=(10, 0))
        self.mode_combo.bind("<<ComboboxSelected>>", self.on_mode_changed)
        tk.Label(mode_row, text="Choose the flow you are testing.", bg=PANEL, fg=MUTED, font=(UI_FONT, 9)).pack(side="left", padx=10)

        tk.Label(
            inner, text="Target site address", bg=PANEL, fg=TEXT,
            font=(UI_FONT, 10)
        ).pack(anchor="w", pady=(10, 4))
        self.site = tk.StringVar(value=DEFAULT_URL)
        self.make_entry(inner, self.site).pack(fill="x", ipady=3)

        options = tk.Frame(inner, bg=PANEL)
        options.pack(fill="x", pady=(14, 0))
        self.test_check = CheckBox(
            options, "Test mode  (fake @example.test addresses only)",
            command=self.on_test_mode_toggled, value=True
        )
        self.test_check.pack(side="left")
        self.permission_check = CheckBox(
            options, "I own this site or have permission to test it",
            command=self.on_permission_toggled
        )
        self.permission_check.pack(side="left", padx=(32, 0))

        # Your list (only shown when test mode is off)
        self.list_frame = tk.Frame(inner, bg=PANEL)

        list_header = tk.Frame(self.list_frame, bg=PANEL)
        list_header.pack(fill="x", pady=(0, 6))
        tk.Label(
            list_header, text="Your list", bg=PANEL, fg=TEXT,
            font=(UI_FONT, 10, "bold")
        ).pack(side="left")
        tk.Label(
            list_header, text="one per line:  Name, email   (max 10)",
            bg=PANEL, fg=MUTED, font=(UI_FONT, 9)
        ).pack(side="left", padx=10)
        self.make_button(
            list_header, "CLEAR LIST", self.clear_list, "danger", small=True
        ).pack(side="right")
        self.make_button(
            list_header, "LOAD FROM FILE", self.load_list_file,
            "secondary", small=True
        ).pack(side="right", padx=6)

        list_wrap = tk.Frame(
            self.list_frame, bg=INPUT_BG, highlightthickness=1,
            highlightbackground=BORDER_LIGHT
        )
        list_wrap.pack(fill="x")
        self.list_box = tk.Text(
            list_wrap, height=5, bg=INPUT_BG, fg=TEXT,
            insertbackground=TEXT, relief="flat", bd=0,
            padx=10, pady=8, font=(MONO_FONT, 10), wrap="none",
            highlightthickness=0
        )
        list_scroll = ttk.Scrollbar(
            list_wrap, orient="vertical", command=self.list_box.yview,
            style="Dark.Vertical.TScrollbar"
        )
        self.list_box.config(yscrollcommand=list_scroll.set)
        list_scroll.pack(side="right", fill="y")
        self.list_box.pack(side="left", fill="x", expand=True)
        self.list_box.bind(
            "<FocusIn>",
            lambda _e: list_wrap.config(highlightbackground=ACCENT_BLUE)
        )
        self.list_box.bind(
            "<FocusOut>",
            lambda _e: list_wrap.config(highlightbackground=BORDER_LIGHT)
        )

    def build_toolbar(self):
        inner = self.make_panel()

        left = tk.Frame(inner, bg=PANEL)
        left.pack(side="left")

        tk.Label(
            left, text="Test users", bg=PANEL, fg=MUTED,
            font=(UI_FONT, 9)
        ).pack(side="left", padx=(0, 8))
        self.amount = tk.IntVar(value=1)
        self.spinbox = tk.Spinbox(
            left, from_=1, to=MAX_ACCOUNTS, textvariable=self.amount,
            width=4, justify="center", fg=TEXT, bg=INPUT_BG,
            insertbackground=TEXT, buttonbackground=BTN_BG,
            disabledbackground=PANEL, disabledforeground=MUTED,
            relief="flat", font=(MONO_FONT, 10),
            highlightthickness=1, highlightbackground=BORDER_LIGHT,
            highlightcolor=ACCENT_BLUE
        )
        self.spinbox.pack(side="left", ipady=4, padx=(0, 8))

        self.make_button(left, "GENERATE", self.generate).pack(side="left", padx=3)
        self.make_button(
            left, "START TEST", self.start_test, "primary"
        ).pack(side="left", padx=3)
        self.browser_summary = tk.Label(left, text="Browser: scanning...", bg=PANEL, fg=MUTED, font=(UI_FONT, 8))
        self.browser_summary.pack(side="left", padx=(12, 0))

        self.divider(left)

        self.make_button(
            left, "CLOSE BROWSER", self.close_browser
        ).pack(side="left", padx=3)
        self.make_button(
            left, "SAVE RESULTS", self.save_results
        ).pack(side="left", padx=3)

        right = tk.Frame(inner, bg=PANEL)
        right.pack(side="right")
        self.make_button(
            right, "DELETE SAVED", self.delete_saved, "danger"
        ).pack(side="right", padx=3)
        self.make_button(right, "CLEAR", self.clear, "danger").pack(side="right", padx=3)
        self.make_button(right, "STOP", self.stop_test, "danger").pack(side="right", padx=3)

    def build_table(self):
        inner = self.make_panel(fill="both", expand=True)
        self.section_title(inner, "RESULTS")

        self.table = tk.Frame(inner, bg=PANEL)
        self.table.pack(fill="both", expand=True, pady=(8, 0))

        headers = ["#", "NAME", "EMAIL", "PASSWORD", "RESULT"]
        sizes = [(0, 46), (2, 150), (3, 220), (2, 150), (1, 120)]
        for column, header in enumerate(headers):
            weight, minsize = sizes[column]
            self.table.columnconfigure(column, weight=weight, minsize=minsize)
            tk.Label(
                self.table, text=header, bg=HEADER_BG, fg=MUTED,
                font=(UI_FONT, 8, "bold"), anchor="w", padx=10, pady=8
            ).grid(row=0, column=column, sticky="ew")

        tk.Frame(self.table, bg=BORDER, height=1).grid(
            row=1, column=0, columnspan=5, sticky="ew"
        )

        self.empty_label = tk.Label(
            self.table,
            text="No accounts yet. Click GENERATE to build the list.",
            bg=PANEL, fg=MUTED, font=(UI_FONT, 10), pady=22
        )
        self.empty_label.grid(row=2, column=0, columnspan=5, sticky="ew")

    def build_log(self):
        inner = self.make_panel(side="bottom", pady=(0, 0))
        self.section_title(inner, "SYSTEM LOG")

        wrap = tk.Frame(inner, bg=LOG_BG, highlightthickness=1, highlightbackground=BORDER)
        wrap.pack(fill="x", pady=(8, 0))
        self.log = tk.Text(
            wrap, height=8, bg=LOG_BG, fg="#9aa8ba",
            relief="flat", bd=0, padx=10, pady=8,
            font=(MONO_FONT, 9), wrap="word", state="disabled",
            highlightthickness=0
        )
        scroll = ttk.Scrollbar(
            wrap, orient="vertical", command=self.log.yview,
            style="Dark.Vertical.TScrollbar"
        )
        self.log.config(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.log.pack(side="left", fill="both", expand=True)

        self.log.tag_config("time", foreground="#566172")
        self.log.tag_config("info", foreground="#9aa8ba")
        self.log.tag_config("warn", foreground=AMBER)
        self.log.tag_config("err", foreground=RED)
        self.log.tag_config("ok", foreground=GREEN_TEXT)

    def build_footer(self):
        footer = tk.Frame(self.outer, bg=BG)
        footer.pack(side="bottom", fill="x", pady=(10, 0))
        tk.Label(
            footer, text=f"{APP_NAME}  v{APP_VERSION}  •  © 2026 {LEAD_DEVELOPER}", bg=BG, fg=MUTED,
            font=(UI_FONT, 9)
        ).pack(side="left")

    def load_settings(self):
        defaults = {
            "operation_mode": "Sign Up / Register",
            "browser": "Auto",
            "delay_seconds": 1.0,
            "headless": False,
            "keep_browser_open": True,
            "screenshot_on_issue": True,
        }
        try:
            with open(SETTINGS_FILE, "r", encoding="utf-8") as handle:
                data = json.load(handle)
            if isinstance(data, dict):
                defaults.update(data)
        except (OSError, ValueError, TypeError):
            pass

        mode = defaults.get("operation_mode")
        defaults["operation_mode"] = mode if mode in {"Sign Up / Register", "Login / Sign In"} else "Sign Up / Register"
        defaults["browser"] = str(defaults.get("browser") or "Auto")
        try:
            defaults["delay_seconds"] = max(0.0, min(30.0, float(defaults.get("delay_seconds", 1.0))))
        except (TypeError, ValueError):
            defaults["delay_seconds"] = 1.0
        defaults["headless"] = bool(defaults.get("headless", False))
        defaults["keep_browser_open"] = bool(defaults.get("keep_browser_open", True))
        defaults["screenshot_on_issue"] = bool(defaults.get("screenshot_on_issue", True))
        return defaults

    def save_settings(self):
        self.settings.update({
            "operation_mode": self.operation_mode,
            "browser": self.preferred_browser,
            "delay_seconds": self.delay_seconds,
            "headless": self.headless,
            "keep_browser_open": self.keep_browser_open,
            "screenshot_on_issue": self.screenshot_on_issue,
        })
        try:
            with open(SETTINGS_FILE, "w", encoding="utf-8") as handle:
                json.dump(self.settings, handle, indent=2)
        except OSError:
            pass

    def _asset_path(self, name):
        """Resolve bundled assets for both source runs and PyInstaller builds."""
        base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
        return os.path.join(base, "assets", name)

    def show_startup_screen(self):
        # A short terminal boot followed by the user's pixel skull.  The skull
        # frames are pre-rendered with nearest-neighbor scaling, so Tk never
        # has to blur/resample the pixel art at runtime.
        overlay = tk.Frame(self.root, bg="#050805")
        self.startup_overlay = overlay
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        overlay.lift()

        title = tk.Label(overlay, text="", bg="#050805", fg=GREEN_TEXT,
                         font=(MONO_FONT, 22, "bold"))
        title.pack(expand=False, pady=(150, 15))
        log = tk.Label(overlay, text="", justify="left", anchor="w",
                       bg="#050805", fg=GREEN_TEXT, font=(MONO_FONT, 10))
        log.pack()

        lines = [
            "> INITIALIZING HYDRA...",
            "> LOADING AUTOMATION CORE...",
            "> CHECKING BROWSER ENGINES...",
            "> LOADING MODULES...",
            "> TEST ENVIRONMENT READY",
        ]
        title.config(text="H Y D R A   A U T O M A T O R")

        def show_skull():
            try:
                title.pack_forget()
                log.pack_forget()
                skull_label = tk.Label(overlay, bg="#050805", bd=0, highlightthickness=0)
                skull_label.pack(expand=True)
                frame_names = [f"skull_{i}.png" for i in range(6)] + [
                    f"skull_glitch_{i}.png" for i in range(4)
                ]
                images = []
                for name in frame_names:
                    path = self._asset_path(name)
                    if os.path.exists(path):
                        images.append(tk.PhotoImage(file=path))
                if not images:
                    overlay.destroy()
                    return
                skull_label.configure(image=images[0])
                # Keep references alive for the whole animation.
                skull_label._hydra_frames = images

                def animate(i=0):
                    if not overlay.winfo_exists():
                        return
                    if i < len(images):
                        skull_label.configure(image=images[i])
                        self.root.after(75, lambda: animate(i + 1))
                    else:
                        # Tiny hold, then a clean cut into the main UI.
                        self.root.after(220, overlay.destroy)
                animate()
            except (tk.TclError, OSError):
                try:
                    overlay.destroy()
                except tk.TclError:
                    pass

        def finish(i=0):
            if i < len(lines):
                current = log.cget("text")
                glitch = lines[i].replace("A", random.choice(["A", "4"])).replace("E", random.choice(["E", "3"]))
                log.config(text=current + ("\n" if current else "") + glitch)
                self.root.after(110, lambda: finish(i + 1))
            else:
                self.root.after(180, show_skull)
        self.root.after(180, finish)

    def on_mode_changed(self, _event=None):
        if self.running:
            self.mode_combo.set(self.operation_mode)
            self.log_message("A test is running. Wait for it to finish first.")
            return
        self.operation_mode = self.mode_combo.get()
        self.save_settings()
        self.log_message("Operation set to " + self.operation_mode + ".")

    def refresh_browser_summary(self):
        try:
            items = browser_inventory()
            launchable = [x["label"] for x in items if x["launchable"]]
            if launchable:
                self.browser_summary.config(text="Browser: " + launchable[0])
            else:
                self.browser_summary.config(text="Browser: none detected")
        finally:
            try:
                self.root.after(3000, self.refresh_browser_summary)
            except tk.TclError:
                pass

    def refresh_browser_inventory(self):
        """Rescan installed and Playwright-managed browsers immediately."""
        items = browser_inventory()
        launchable = [x["label"] for x in items if x["launchable"]]
        self.log_message("Browser inventory refreshed: " + (", ".join(launchable) if launchable else "none launchable"))
        self.refresh_browser_summary()
        return items

    def open_settings(self):
        existing = getattr(self, "settings_window", None)
        if existing is not None:
            try:
                if existing.winfo_exists():
                    existing.lift()
                    return
            except tk.TclError:
                self.settings_window = None
        win = tk.Toplevel(self.root)
        self.settings_window = win
        win.title("Hydra Settings")
        win.geometry("500x500")
        win.configure(bg=PANEL)
        win.resizable(False, False)
        body = tk.Frame(win, bg=PANEL)
        body.pack(fill="both", expand=True, padx=20, pady=18)
        tk.Label(body, text="SETTINGS", bg=PANEL, fg=TEXT, font=(UI_FONT, 15, "bold")).pack(anchor="w")
        tk.Label(body, text="These preferences are saved in your user app-data folder.", bg=PANEL, fg=MUTED, font=(UI_FONT, 9)).pack(anchor="w", pady=(2, 16))

        row = tk.Frame(body, bg=PANEL); row.pack(fill="x", pady=6)
        tk.Label(row, text="Browser", bg=PANEL, fg=TEXT, font=(UI_FONT, 10)).pack(side="left")
        browser_values = ["Auto"] + sorted(set(x["label"] for x in browser_inventory() if x["launchable"]))
        browser_combo = ttk.Combobox(row, state="readonly", width=27, values=browser_values)
        browser_combo.set(self.preferred_browser if self.preferred_browser in browser_values else "Auto")
        browser_combo.pack(side="right")

        row = tk.Frame(body, bg=PANEL); row.pack(fill="x", pady=6)
        tk.Label(row, text="Delay between accounts (sec)", bg=PANEL, fg=TEXT, font=(UI_FONT, 10)).pack(side="left")
        delay_var = tk.StringVar(value=str(self.delay_seconds))
        tk.Entry(row, textvariable=delay_var, width=8, bg=INPUT_BG, fg=TEXT, insertbackground=TEXT, relief="flat").pack(side="right")

        headless_var = tk.BooleanVar(value=self.headless)
        keep_var = tk.BooleanVar(value=self.keep_browser_open)
        shot_var = tk.BooleanVar(value=self.screenshot_on_issue)
        tk.Checkbutton(body, text="Headless browser", variable=headless_var, bg=PANEL, fg=TEXT, selectcolor=INPUT_BG, activebackground=PANEL, activeforeground=TEXT).pack(anchor="w", pady=5)
        tk.Checkbutton(body, text="Keep browser open after a run", variable=keep_var, bg=PANEL, fg=TEXT, selectcolor=INPUT_BG, activebackground=PANEL, activeforeground=TEXT).pack(anchor="w", pady=5)
        tk.Checkbutton(body, text="Screenshot on error / CAPTCHA", variable=shot_var, bg=PANEL, fg=TEXT, selectcolor=INPUT_BG, activebackground=PANEL, activeforeground=TEXT).pack(anchor="w", pady=5)

        dob_row = tk.Frame(body, bg=PANEL); dob_row.pack(fill="x", pady=(10, 4))
        tk.Label(dob_row, text="Test date of birth", bg=PANEL, fg=TEXT, font=(UI_FONT, 10)).pack(side="left")
        dob_m = tk.StringVar(value=self.dob_month); dob_d = tk.StringVar(value=self.dob_day); dob_y = tk.StringVar(value=self.dob_year)
        for var, width in ((dob_m, 3), (dob_d, 3), (dob_y, 5)):
            tk.Entry(dob_row, textvariable=var, width=width, bg=INPUT_BG, fg=TEXT, insertbackground=TEXT, relief="flat").pack(side="left", padx=(8, 0))
        fmt_var = tk.StringVar(value=self.dob_format)
        fmt = ttk.Combobox(dob_row, state="readonly", width=12, textvariable=fmt_var, values=["MM/DD/YYYY", "DD/MM/YYYY", "YYYY-MM-DD"])
        fmt.pack(side="right")

        tk.Label(body, text="DETECTED BROWSERS", bg=PANEL, fg=MUTED, font=(UI_FONT, 8, "bold")).pack(anchor="w", pady=(14, 4))
        browser_text = tk.Text(body, height=6, bg=LOG_BG, fg=GREEN_TEXT, relief="flat", bd=0, font=(MONO_FONT, 9))
        browser_text.pack(fill="x")
        for item in browser_inventory():
            status = ("AVAILABLE" if item.get("detected") else "AVAILABLE / MANAGED") if item["launchable"] else "DETECTED / NOT DIRECTLY LAUNCHABLE"
            browser_text.insert("end", f"{item['label']}: {status}\n")
        browser_text.config(state="disabled")
        tk.Label(body, text="Playwright Chromium, Firefox, and WebKit are managed engines. Installed Chromium-family browsers are directly selectable; installed Firefox/Safari are detected separately.", bg=PANEL, fg=MUTED, font=(UI_FONT, 8), wraplength=410, justify="left").pack(anchor="w", pady=(4, 0))

        def finish_close():
            try:
                win.destroy()
            finally:
                self.settings_window = None

        def save_and_close():
            try:
                delay = max(0.0, min(30.0, float(delay_var.get())))
            except (TypeError, ValueError):
                delay = 1.0
            self.preferred_browser = browser_combo.get()
            self.delay_seconds = delay
            self.headless = headless_var.get()
            self.keep_browser_open = keep_var.get()
            self.screenshot_on_issue = shot_var.get()
            def clean_num(value, default, lo, hi, width):
                try:
                    n = int(str(value).strip())
                    if not (lo <= n <= hi): raise ValueError
                    return f"{n:0{width}d}"
                except Exception:
                    return default
            self.dob_month = clean_num(dob_m.get(), "01", 1, 12, 2)
            self.dob_day = clean_num(dob_d.get(), "01", 1, 31, 2)
            self.dob_year = clean_num(dob_y.get(), "2000", 1900, 2100, 4)
            self.dob_format = fmt_var.get()
            self.settings.update({"dob_month": self.dob_month, "dob_day": self.dob_day, "dob_year": self.dob_year, "dob_format": self.dob_format})
            self.save_settings()
            self.refresh_browser_summary()
            self.log_message("Settings saved.")
            finish_close()
        win.protocol("WM_DELETE_WINDOW", finish_close)
        self.make_button(body, "SAVE SETTINGS", save_and_close, "primary").pack(side="right", pady=(16, 0))
        self.make_button(body, "CANCEL", finish_close).pack(side="right", pady=(16, 0), padx=6)

    def open_credits(self):
        win = tk.Toplevel(self.root)
        win.title("About / Credits")
        win.geometry("430x300")
        win.configure(bg=PANEL)
        body = tk.Frame(win, bg=PANEL)
        body.pack(fill="both", expand=True, padx=24, pady=24)
        tk.Label(body, text=APP_NAME, bg=PANEL, fg=TEXT, font=(UI_FONT, 18, "bold")).pack()
        tk.Label(body, text=f"Version {APP_VERSION}", bg=PANEL, fg=MUTED, font=(UI_FONT, 9)).pack(pady=(2, 18))
        tk.Label(body, text=f"Built by {LEAD_DEVELOPER}", bg=PANEL, fg=TEXT, font=(UI_FONT, 10)).pack()
        tk.Label(body, text="Authorized website testing utility.", bg=PANEL, fg=MUTED, font=(UI_FONT, 9)).pack(pady=8)
        tk.Label(body, text="Uses Python + Playwright.", bg=PANEL, fg=MUTED, font=(UI_FONT, 9)).pack()
        tk.Label(body, text=f"© 2026 {LEAD_DEVELOPER}. All rights reserved.", bg=PANEL, fg=MUTED, font=(UI_FONT, 9)).pack(pady=(22, 8))
        self.make_button(body, "CLOSE", win.destroy).pack(pady=8)

    # ----- switches -----

    def on_permission_toggled(self):
        self.permission_ok = self.permission_check.get()

    def on_test_mode_toggled(self):
        if self.running:
            self.test_check.set(self.test_mode)
            self.log_message("A test is running. Wait for it to finish first.")
            return
        self.test_mode = self.test_check.get()
        self.clear_rows_only()
        self.show_status("READY")
        self.update_test_mode_ui()
        if self.test_mode:
            self.log_message("Test mode on: fake @example.test addresses only.")
        else:
            self.log_message("Test mode off: type your own list, then GENERATE.")

    def update_test_mode_ui(self):
        if self.test_mode:
            self.list_frame.pack_forget()
            self.spinbox.config(state="normal")
            self.root.geometry("1000x780")
        else:
            self.list_frame.pack(fill="x", pady=(14, 0))
            self.spinbox.config(state="disabled")
            self.root.geometry("1000x920")

    # ----- safe way for the background thread to update the window -----

    def ui(self, func, *args):
        self.ui_queue.put((func, args))

    def process_queue(self):
        try:
            while True:
                func, args = self.ui_queue.get_nowait()
                func(*args)
        except queue.Empty:
            pass
        self.root.after(100, self.process_queue)

    def log_message(self, message):
        self.ui(self._write_log, message)

    def _write_log(self, message):
        level = classify_log(message)
        self.log.config(state="normal")
        self.log.insert("end", time.strftime("%H:%M:%S") + "  ", "time")
        self.log.insert("end", message + "\n", level)
        self.log.see("end")
        self.log.config(state="disabled")

    def set_status(self, text):
        self.ui(self.show_status, text)

    def show_status(self, text):
        text = text.replace("STATUS:", "").strip()
        self.badge_dot.config(fg=status_color(text))
        self.badge_text.config(text=text)

    def set_result(self, index, text):
        def apply():
            try:
                apply_badge(self.rows[index]["labels"][4], text)
            except IndexError:
                pass

        self.ui(apply)

    # ----- test data -----

    def fake_account(self, number):
        name = random.choice(FAKE_NAMES)
        email = f"test_{number}_{random.randint(1000, 9999)}@{TEST_DOMAIN}"
        return name, email, make_password()

    def generate(self):
        if self.running:
            self.log_message("A test is running. Wait for it to finish first.")
            return

        if self.test_mode:
            try:
                amount = max(1, min(MAX_ACCOUNTS, int(self.amount.get())))
            except (ValueError, tk.TclError):
                amount = 1
            accounts = [self.fake_account(n) for n in range(1, amount + 1)]
        else:
            accounts, problems = parse_account_list(
                self.list_box.get("1.0", "end")
            )
            if problems:
                for problem in problems:
                    self.log_message(problem)
                messagebox.showinfo("Check your list", "\n".join(problems[:8]))
                return
            if not accounts:
                messagebox.showinfo(
                    "Nothing entered",
                    "Type at least one line like:  Alex Smith, alex@yoursite.com"
                )
                return

        self.clear_rows_only()

        for number, (name, email, password) in enumerate(accounts, start=1):
            bg = PANEL if number % 2 else PANEL_ALT
            grid_row = number + 1
            labels, widgets = [], []

            for column, value in enumerate([str(number), name, email, password]):
                label = tk.Label(
                    self.table, text=value, bg=bg,
                    fg=MUTED if column == 0 else TEXT,
                    font=(MONO_FONT, 10), anchor="w", padx=10, pady=7
                )
                label.grid(row=grid_row, column=column, sticky="ew")
                labels.append(label)
                widgets.append(label)

            cell = tk.Frame(self.table, bg=bg)
            cell.grid(row=grid_row, column=4, sticky="nsew")
            badge = tk.Label(cell, font=(UI_FONT, 8, "bold"), padx=10, pady=2)
            badge.pack(anchor="w", padx=10, pady=6)
            apply_badge(badge, "READY")
            labels.append(badge)
            widgets.append(cell)

            self.rows.append({
                "name": name, "email": email, "password": password,
                "labels": labels, "widgets": widgets
            })

        self.refresh_placeholder()
        count = len(accounts)
        source = "fake data" if self.test_mode else "your list"
        self.show_status(f"{count} RECORD(S) READY")
        self.log_message(f"Built {count} record(s) from {source}.")

    def clear_rows_only(self):
        for row in self.rows:
            for widget in row["widgets"]:
                widget.destroy()
        self.rows.clear()
        self.refresh_placeholder()

    def refresh_placeholder(self):
        if self.rows:
            self.empty_label.grid_remove()
        else:
            self.empty_label.grid()

    def clear(self):
        if self.running:
            self.log_message("A test is running. Wait for it to finish first.")
            return
        self.clear_rows_only()
        self.show_status("READY")
        self.log_message("Cleared test records.")

    # ----- running the test -----

    def start_test(self):
        if self.running:
            self.log_message("A test is already running.")
            return

        if not self.rows:
            messagebox.showinfo("Nothing to test", "Click GENERATE first.")
            return

        if not self.permission_ok:
            self.show_status("TICK THE PERMISSION BOX FIRST")
            self.log_message("Blocked: tick the permission box before starting.")
            messagebox.showinfo(
                "Permission needed",
                "Tick the box confirming you own this site or have "
                "permission to test it."
            )
            return

        url = normalize_url(self.site.get())
        if not url:
            messagebox.showinfo(
                "Site address",
                "Enter a valid http:// or https:// website address."
            )
            return

        if len(self.rows) > MAX_ACCOUNTS:
            self.log_message(f"The limit is {MAX_ACCOUNTS} accounts per run.")
            return

        accounts = [(r["name"], r["email"], r["password"]) for r in self.rows]
        for index in range(len(accounts)):
            self.set_result(index, "READY")

        run = {
            "stop_event": threading.Event(),
            "close_event": threading.Event(),
            "session": None,
        }
        self.active_run = run
        self.running = True
        self.current_page = None
        self.show_status("STARTING BROWSER...")
        self.log_message(f"Mode: {self.operation_mode}. Browser preference: {self.preferred_browser}.")
        threading.Thread(target=self.run_browser, args=(url, accounts, run), daemon=True).start()

    def stop_test(self):
        run = self.active_run
        if not self.running or not run:
            self.log_message("Nothing is running.")
            return
        run["stop_event"].set()
        self.log_message("Stopping... the browser will stay open.")

    def should_stop(self, run=None):
        run = run or self.active_run
        return bool(run and (run["stop_event"].is_set() or run["close_event"].is_set()))

    def skip_rest(self, start_index, total):
        for i in range(start_index, total):
            self.set_result(i, "SKIPPED")

    def save_screenshot(self, page, number, result):
        try:
            os.makedirs(SCREENSHOT_DIR, exist_ok=True)
            stamp = time.strftime("%Y%m%d-%H%M%S")
            label = result.replace(" ", "_")
            filename = f"account{number}_{label}_{stamp}.png"
            page.screenshot(
                path=os.path.join(SCREENSHOT_DIR, filename),
                full_page=True, timeout=10000
            )
            self.log_message(f"[{number}] Saved a picture: screenshots\\" + filename)
        except Exception:
            self.log_message(f"[{number}] Couldn't take a picture of the page.")

    # ----- files -----

    def save_results(self):
        if not self.rows:
            messagebox.showinfo("Nothing to save", "Click GENERATE first.")
            return
        os.makedirs(RESULTS_DIR, exist_ok=True)
        path = filedialog.asksaveasfilename(
            title="Save results",
            initialdir=RESULTS_DIR,
            defaultextension=".csv",
            initialfile="results_" + time.strftime("%Y%m%d-%H%M%S") + ".csv",
            filetypes=[("CSV (opens in Excel)", "*.csv"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as handle:
                writer = csv.writer(handle)
                writer.writerow(["#", "Name", "Email", "Password", "Result"])
                for number, row in enumerate(self.rows, start=1):
                    writer.writerow([
                        number, row["name"], row["email"], row["password"],
                        row["labels"][4].cget("text")
                    ])
            self.log_message("Saved results to " + path)
        except OSError as error:
            messagebox.showerror("Couldn't save", short(error))

    def delete_saved(self):
        if self.running:
            self.log_message("A test is running. Wait for it to finish first.")
            return
        files = list_saved_files()
        if not files:
            messagebox.showinfo(
                "Nothing to delete",
                "There are no saved results or screenshots yet."
            )
            return
        sure = messagebox.askyesno(
            "Delete saved results",
            f"Delete {len(files)} saved file(s)?\n\n"
            "This removes the pictures in the 'screenshots' folder and the "
            "result files in your Hydra Automator user-data folder. "
            "It can't be undone."
        )
        if not sure:
            return
        deleted = 0
        for path in files:
            try:
                os.remove(path)
                deleted += 1
            except OSError:
                pass
        self.log_message(f"Deleted {deleted} saved file(s).")
        if deleted < len(files):
            self.log_message(
                f"Couldn't delete {len(files) - deleted} file(s). "
                "They may be open in another program."
            )

    def load_list_file(self):
        path = filedialog.askopenfilename(
            title="Open your list",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8-sig", errors="replace") as handle:
                text = handle.read(20000)
        except OSError as error:
            messagebox.showerror("Couldn't open file", short(error))
            return
        self.list_box.delete("1.0", "end")
        self.list_box.insert("1.0", text)
        count = len([line for line in text.splitlines() if line.strip()])
        self.log_message(f"Loaded {count} line(s) from {os.path.basename(path)}.")
        if count > MAX_ACCOUNTS:
            self.log_message(
                f"Heads up: the limit is {MAX_ACCOUNTS}. Trim the list before GENERATE."
            )

    def clear_list(self):
        self.list_box.delete("1.0", "end")
        self.log_message("Notepad cleared.")

    def close_browser(self):
        if not self.browser_sessions:
            self.log_message("No browser is open.")
            return
        for session in list(self.browser_sessions):
            session["close_event"].set()
        if self.active_run:
            self.active_run["stop_event"].set()
        self.log_message("Closing browser...")


    # ----- the browser run (background thread) -----

    def run_browser(self, url, accounts, run):
        session = None
        final_status = None
        try:
            bundled = _bundled_browser_root()
            if bundled:
                os.environ["PLAYWRIGHT_BROWSERS_PATH"] = bundled
            with sync_playwright() as playwright:
                self.log_message("Launching browser...")
                browser, browser_label = launch_browser(
                    playwright, self.log_message, self.preferred_browser, self.headless
                )
                self.log_message(f"Browser ready: {browser_label}.")
                session = {"browser": browser, "close_event": run["close_event"]}
                run["session"] = session
                self.browser_sessions.append(session)

                try:
                    final_status = self.run_accounts(browser, url, accounts, run)
                except Exception as error:
                    final_status = "ERROR - READY TO RESTART"
                    self.log_message("ERROR: " + short(error))
                    self.ui(messagebox.showerror, "Automation Error", short(error))

                # The automation run itself is now finished. This intentionally
                # unlocks START TEST even while the inspection browser remains open.
                if self.active_run is run:
                    self.running = False
                    self.active_run = None

                if run["close_event"].is_set() or not self.keep_browser_open:
                    if run["close_event"].is_set() and final_status and final_status.startswith("STOPPED - BROWSER STAYS OPEN"):
                        final_status = "STOPPED - BROWSER CLOSED"
                    try:
                        browser.close()
                    except Exception:
                        pass
                else:
                    # Keep the Playwright owner thread alive for this browser session.
                    self.hold_open(browser, run["close_event"])
                    try:
                        browser.close()
                    except Exception:
                        pass

            if final_status:
                self.set_status(final_status)
            if run["close_event"].is_set() or not self.keep_browser_open:
                self.log_message("Browser closed.")
            else:
                self.log_message("Automation finished; browser remains available for inspection.")
        except Exception as error:
            self.log_message("ERROR: " + short(error))
            self.set_status("ERROR - READY TO RESTART")
            if self.active_run is run:
                self.running = False
                self.active_run = None
            self.ui(messagebox.showerror, "Automation Error", short(error))
        finally:
            if session in self.browser_sessions:
                self.browser_sessions.remove(session)
            if self.active_run is run:
                self.active_run = None
                self.running = False


    def run_accounts(self, browser, url, accounts, run):
        previous = None
        total = len(accounts)
        mode_key = "login" if self.operation_mode == "Login / Sign In" else "signup"

        try:
            for index, (name, email, password) in enumerate(accounts):
                if self.should_stop(run):
                    self.skip_rest(index, total)
                    self.log_message("Stopped. Browser stays open.")
                    return "STOPPED - BROWSER STAYS OPEN"

                number = index + 1
                self.set_result(index, "RUNNING")
                self.set_status(f"ACCOUNT {number} OF {total}")

                context = browser.new_context()
                page = context.new_page()

                # Lightweight security telemetry: record the latest response
                # status so the result engine can distinguish ordinary form
                # failures from site-level 403/429 defenses.
                def remember_response(response):
                    try:
                        status = response.status
                        page._hydra_last_status = status
                        if status in (401, 403, 429):
                            self.log_message(
                                f"[{number}] Server response: HTTP {status} ({response.url})"
                            )
                    except Exception:
                        pass
                page.on("response", remember_response)

                self.current_page = page
                page._hydra_dob_month = self.dob_month
                page._hydra_dob_day = self.dob_day
                page._hydra_dob_year = self.dob_year
                page._hydra_dob_format = self.dob_format

                if previous is not None:
                    try:
                        previous.close()
                    except Exception:
                        pass
                previous = context

                self.log_message(f"[{number}] Opening {url}")
                try:
                    page.goto(url, wait_until="domcontentloaded", timeout=30000)
                    detected = detect_flow_elements(page, mode_key)
                    if detected:
                        self.log_message(
                            f"[{number}] Detected {mode_key} control(s): " + ", ".join(detected[:3])
                        )
                    else:
                        self.log_message(
                            f"[{number}] No obvious {mode_key} control detected; trying the page directly."
                        )

                    if self.operation_mode == "Login / Sign In":
                        result = login_account(
                            page, number, email, password, self.log_message,
                            lambda: self.should_stop(run)
                        )
                    else:
                        result = register_account(
                            page, number, name, email, password, self.log_message,
                            lambda: self.should_stop(run)
                        )
                except Exception as error:
                    self.log_message(f"[{number}] Problem: " + short(error))
                    result = "FAIL"

                self.set_result(index, result)

                if result == "STOPPED":
                    self.skip_rest(index + 1, total)
                    self.log_message("Stopped. Browser stays open.")
                    return "STOPPED - BROWSER STAYS OPEN"

                if result != "PASS":
                    if self.screenshot_on_issue:
                        self.save_screenshot(page, number, result)
                    self.skip_rest(index + 1, total)
                    self.log_message("Stopped here. Browser left open so you can take a look.")
                    return f"STOPPED AT ACCOUNT {number} ({result})"

                if self.delay_seconds > 0:
                    page.wait_for_timeout(int(self.delay_seconds * 1000))

            return "ALL DONE - BROWSER STAYS OPEN" if self.keep_browser_open else "ALL DONE"
        finally:
            if previous is not None and not self.keep_browser_open:
                try:
                    previous.close()
                except Exception:
                    pass


    def hold_open(self, browser, close_event):
        self.log_message(
            "Browser stays open for inspection. Press CLOSE BROWSER when done."
        )
        while not close_event.is_set():
            try:
                if not browser.contexts:
                    break
                close_event.wait(0.5)
            except Exception:
                break


if __name__ == "__main__":
    window = tk.Tk()
    # Tk now sees the real monitor DPI on Windows. Do not apply a second
    # manual scale factor here; that would make text/images soft again.
    AutomationApp(window)
    window.mainloop()
