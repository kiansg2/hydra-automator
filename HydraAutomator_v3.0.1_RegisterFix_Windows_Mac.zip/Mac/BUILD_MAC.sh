#!/bin/bash
set -e
cd "$(dirname "$0")"
export PLAYWRIGHT_BROWSERS_PATH=0

echo "Installing build tools (one time)..."
python3 -m pip install --upgrade pyinstaller playwright

echo "Installing bundled Playwright Chromium..."
python3 -m playwright install chromium

PW_CACHE="$(python3 -c 'import os, playwright; print(os.path.join(os.path.dirname(playwright.__file__), "driver", "package", ".local-browsers"))')"
if [ ! -d "$PW_CACHE" ]; then
  echo "Could not find the Playwright browser bundle."
  exit 1
fi

echo "Building Hydra Automator for macOS..."
python3 -m PyInstaller --noconfirm --windowed --name HydraAutomator --collect-all playwright --add-data "$PW_CACHE:ms-playwright" --add-data "assets:assets" playlab_automation.py

echo
echo "Done! Your app is in dist/HydraAutomator.app"
