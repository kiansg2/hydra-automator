HYDRA AUTOMATOR // macOS

Open Terminal in this folder and run:
    ./BUILD_MAC.sh

The finished application will be in dist/HydraAutomator.app.

The source app is playlab_automation.py.

The app detects installed Chrome, Edge, Brave, Opera, Chromium, and Firefox. Safari is detected for information, but Playwright does not launch the installed Safari application directly.

- Detects objective HTTP 403/429/security-challenge signals and stops for inspection; no CAPTCHA or anti-bot bypass is included.
