HYDRA AUTOMATOR // WINDOWS

Open BUILD_WINDOWS.bat to build the Windows app.
The finished application will be in dist\HydraAutomator.exe.

The source app is playlab_automation.py.

The app detects installed Chrome, Edge, Brave, Opera, Chromium, and Firefox where their executable can be found.

- Detects objective HTTP 403/429/security-challenge signals and stops for inspection; no CAPTCHA or anti-bot bypass is included.
