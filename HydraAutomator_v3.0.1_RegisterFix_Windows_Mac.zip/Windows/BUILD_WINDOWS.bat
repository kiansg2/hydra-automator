@echo off
setlocal
cd /d "%~dp0"
set PLAYWRIGHT_BROWSERS_PATH=0

echo Installing build tools (one time)...
py -m pip install --upgrade pyinstaller playwright
if errorlevel 1 (
  echo.
  echo Install failed.
  pause
  exit /b 1
)

echo.
echo Installing bundled Playwright Chromium...
py -m playwright install chromium
if errorlevel 1 (
  echo.
  echo Browser install failed.
  pause
  exit /b 1
)

for /f "delims=" %%P in ('py -c "import os,playwright; print(os.path.join(os.path.dirname(playwright.__file__), 'driver', 'package', '.local-browsers'))"') do set PW_CACHE=%%P
if not exist "%PW_CACHE%" (
  echo.
  echo Could not find the Playwright browser bundle.
  pause
  exit /b 1
)

echo.
echo Building Hydra Automator for Windows...
py -m PyInstaller --noconfirm --onefile --windowed --name HydraAutomator --collect-all playwright --add-data "%PW_CACHE%;ms-playwright" --add-data "assets;assets" playlab_automation.py
if errorlevel 1 (
  echo.
  echo Build failed.
  pause
  exit /b 1
)

echo.
echo Done! Your app is in dist\HydraAutomator.exe
pause
