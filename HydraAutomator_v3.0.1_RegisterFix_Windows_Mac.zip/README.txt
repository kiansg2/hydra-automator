HYDRA AUTOMATOR v3.0

Windows and macOS test builds.

V3 foundation: security-response telemetry and clearer automation/session lifecycle handling.

Highlights:
- Browser inventory and manual browser selection
- Playwright Chromium / Firefox / WebKit choices
- Chrome, Edge, Brave, Opera, Opera GX, Vivaldi, Chromium, Arc and Thorium detection where installed
- Refresh browser inventory from Settings
- Login / Sign Up flow selection and robust form detection
- Month / Day / Year test DOB settings and common DOB field detection
- CAPTCHA/challenge detection with manual intervention; no CAPTCHA bypass is included
- Persistent settings and separate Windows/macOS user-data locations

Use only on sites you own or have explicit permission to test.

- Detects objective HTTP 403/429/security-challenge signals and stops for inspection; no CAPTCHA or anti-bot bypass is included.
