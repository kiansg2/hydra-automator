HYDRA AUTOMATOR v3.2.0 // HYDRA LINK

Desktop + phone companion update.

NEW
- Hydra Link: control an authorized test running on the desktop from a phone on the same LAN.
- Secure per-launch pairing code + random session token.
- Live phone status for run state, record count, browser state, and current Hydra status.
- Phone controls: GENERATE, START TEST, STOP, CLOSE BROWSER.
- Desktop shows the phone connection address and pairing code.
- Browser remains open after a run or manual intervention, as before.
- Automatic page navigation toggle remains available.
- CAPTCHA detection remains a hard stop; Hydra does not solve or bypass CAPTCHA.
- No stealth/WebDriver-hiding feature is included.

PHONE SETUP
1. Start Hydra Automator on Windows or macOS.
2. Put the phone and computer on the same local network.
3. Open the /mobile address shown in Hydra, or use the separate Hydra Link mobile companion.
4. Enter the desktop address and 6-digit pairing code.
5. Use the phone dashboard to control the paired desktop workflow.

SECURITY
- A fresh random session token is generated each launch.
- Keep the pairing code private and only pair devices you control.
- Do not expose the Hydra Link port directly to the public internet.

GOOGLE DRIVE / CLOUD STORAGE
- The exact Google Drive feature from the older planning chat was not recoverable in the available project files, so it is not silently reimplemented here.
- This release does not create hidden cloud storage or upload data without an explicit user action.
