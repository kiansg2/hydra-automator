Hydra Automator v3.2.1 Register Fix

Register submission was hardened so the practice site's Register control is
found by accessible role first, with a visible-button/input fallback if the
site's accessible role changes. The existing CAPTCHA/manual-intervention and
browser-left-open behavior is unchanged.

This source was syntax-checked with Python's py_compile. A live website run
was not performed in this environment.
