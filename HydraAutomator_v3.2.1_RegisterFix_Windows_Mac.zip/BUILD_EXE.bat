@echo off
cd /d "%~dp0"
echo Installing build tools (one time)...
py -m pip install --upgrade pyinstaller playwright
if errorlevel 1 (
  echo.
  echo Install failed.
  pause
  exit /b 1
)
echo.
echo Building Hydra Automator...
py -m PyInstaller --noconfirm --onefile --windowed --name HydraAutomator --collect-all playwright playlab_automation.py
if errorlevel 1 (
  echo.
  echo Build failed.
  pause
  exit /b 1
)
echo.
echo Done! Your app is in the "dist" folder: HydraAutomator.exe
echo Copy that one file to any Windows laptop. It uses the laptop's Microsoft Edge or Google Chrome.
pause
