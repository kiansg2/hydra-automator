import csv
import json
import socket
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse
import os
import queue
import random
import re
import string
import sys
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from playwright.sync_api import sync_playwright

# A packaged (.exe) app has no console, so give the print streams somewhere to go.
if sys.stdout is None:
    sys.stdout = open(os.devnull, "w")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w")

# ---------------------------------------------------------------------------
# App identity  (change LEAD_DEVELOPER to your name)
# ---------------------------------------------------------------------------
APP_NAME = "Hydra Automator"
APP_VERSION = "3.2.0"
LEAD_DEVELOPER = "Your Name"

# Default target: the safe practice site.
DEFAULT_URL = "https://playwrightlab.github.io/"
TEST_DOMAIN = "example.test"
MAX_ACCOUNTS = 10
FAKE_NAMES = [
    "Alex Smith", "Jordan Lee", "Sam Brown",
    "Taylor Miller", "Chris Wilson", "Drew Davis"
]
EMAIL_FINDER = re.compile(r"[^@\s,;]+@[^@\s,;]+\.[^@\s,;]+")

if getattr(sys, "frozen", False):
    APP_DIR = os.path.dirname(sys.executable)
else:
    APP_DIR = os.path.dirname(os.path.abspath(__file__))
SCREENSHOT_DIR = os.path.join(APP_DIR, "screenshots")
RESULTS_DIR = os.path.join(APP_DIR, "results")
HYDRA_LINK_PORT = 8765

# ---------------------------------------------------------------------------
# Look and feel
# ---------------------------------------------------------------------------
UI_FONT = "Segoe UI"
MONO_FONT = "Consolas"

BG = "#0f1318"            # window
PANEL = "#171c23"         # panels
PANEL_ALT = "#1b212a"     # zebra rows
HEADER_BG = "#1e2530"     # table header
INPUT_BG = "#11161c"
LOG_BG = "#0c1015"
BORDER = "#2a323d"
BORDER_LIGHT = "#3a4453"

TEXT = "#e4e8ee"
MUTED = "#8a94a3"

ACCENT_BLUE = "#4c8dff"   # focus rings
BLUE_INFO = "#79b8ff"
GREEN_TEXT = "#5fd39a"
GREEN_FILL = "#2a9d6f"    # primary action
GREEN_HOVER = "#33b07d"
AMBER = "#e3b341"
RED = "#e57373"
RED_BORDER = "#6b3a40"
RED_HOVER = "#2b1f24"
BTN_BG = "#232a35"
BTN_HOVER = "#2d3644"

# Result badges: (text color, background color)
BADGES = {
    "PASS": (GREEN_TEXT, "#13332a"),
    "FAIL": ("#f08c8c", "#3a1d22"),
    "CHECK": (AMBER, "#3a2f14"),
    "CAPTCHA": (AMBER, "#3a2f14"),
    "NO FORM": (AMBER, "#3a2f14"),
    "STOPPED": (AMBER, "#3a2f14"),
    "RUNNING": (BLUE_INFO, "#152a44"),
}
DEFAULT_BADGE = (MUTED, "#232a35")

# Only these kinds of files inside the app's own folders are ever deleted.
SAVED_DIRS = [(SCREENSHOT_DIR, (".png",)), (RESULTS_DIR, (".csv",))]


def apply_badge(label, text):
    fg, bg = BADGES.get(text, DEFAULT_BADGE)
    label.config(text=text, fg=fg, bg=bg)


def status_color(text):
    """Pick the dot color for the status badge."""
    t = text.upper()
    if "ERROR" in t:
        return RED
    if any(word in t for word in ("STOPPED", "TICK", "PERMISSION")):
        return AMBER
    if any(word in t for word in ("ALL DONE", "RECORD(S) READY")):
        return GREEN_TEXT
    if any(word in t for word in ("ACCOUNT", "STARTING", "LAUNCH")):
        return BLUE_INFO
    return MUTED


def classify_log(message):
    """Decide the color of a log line: warn (amber), err, ok (green) or info."""
    text = message.lower()
    if any(word in text for word in (
        "captcha", "stopped", "stopping", "heads up", "couldn't tell",
        "limit is", "blocked", "wait for it", "tick the", "nothing is running",
        "nothing to", "already running", "no browser", "no email address found",
        "same email as", "you entered"
    )):
        return "warn"
    if any(word in text for word in (
        "error", "problem", "couldn't", "failed", "can't"
    )):
        return "err"
    if any(word in text for word in (
        "saved", "loaded", "built", "all done", "looks like it worked",
        "success", "cleared", "deleted", "system online", "browser closed"
    )):
        return "ok"
    return "info"


def list_saved_files():
    """Files the app itself saved (screenshots and result sheets)."""
    found = []
    for folder, extensions in SAVED_DIRS:
        if not os.path.isdir(folder):
            continue
        for name in os.listdir(folder):
            path = os.path.join(folder, name)
            if os.path.isfile(path) and name.lower().endswith(extensions):
                found.append(path)
    return found


def launch_browser(playwright, log):
    """Open a visible browser. Prefers the laptop's own Edge or Chrome, so
    nothing extra needs to be downloaded. Falls back to Playwright's Chromium."""
    attempts = [
        ("Microsoft Edge", {"channel": "msedge"}),
        ("Google Chrome", {"channel": "chrome"}),
        ("built-in Chromium", {}),
    ]
    for label, options in attempts:
        try:
            browser = playwright.chromium.launch(headless=False, **options)
            log(f"Using {label}.")
            return browser
        except Exception:
            continue
    raise RuntimeError(
        "No browser found. Install Microsoft Edge or Google Chrome, "
        "or run INSTALL_PLAYWRIGHT.bat once."
    )


# ---------------------------------------------------------------------------
# Form-handling helpers (no window code in here)
# ---------------------------------------------------------------------------

CAPTCHA_SELECTOR = (
    'iframe[src*="recaptcha"], iframe[src*="hcaptcha"], '
    'iframe[src*="challenges.cloudflare.com"], '
    ".g-recaptcha, .h-captcha, .cf-turnstile"
)

# Looks at every visible box on the page and reports what it seems to be for.
FIELD_SCRIPT = """
() => {
  const out = [];
  const inputs = Array.from(document.querySelectorAll('input, textarea'));
  const skip = ['hidden','submit','button','image','reset','file','radio','range','color'];
  let i = 0;
  for (const el of inputs) {
    const type = (el.getAttribute('type') || 'text').toLowerCase();
    if (skip.includes(type)) continue;
    const r = el.getBoundingClientRect();
    const style = window.getComputedStyle(el);
    if (r.width === 0 || r.height === 0 ||
        style.visibility === 'hidden' || style.display === 'none') continue;
    let label = '';
    if (el.labels && el.labels.length) {
      label = Array.from(el.labels).map(l => l.innerText).join(' ');
    }
    el.setAttribute('data-pl-idx', String(i));
    out.push({
      idx: i,
      type: type,
      text: [el.name, el.id, el.placeholder, el.getAttribute('aria-label'),
             el.autocomplete, label].join(' ').toLowerCase()
    });
    i++;
  }
  return out;
}
"""

SOCIAL_WORDS = re.compile(
    r"google|facebook|apple|github|microsoft|twitter|linkedin|sso", re.I
)
ERROR_WORDS = re.compile(
    r"already (exists|registered|in use|taken)|is taken|invalid|failed|"
    r"try again|not valid|something went wrong|an error",
    re.I,
)
SUCCESS_WORDS = re.compile(
    r"success|welcome|thank you|thanks for|registered|account (has been )?created|"
    r"check your (email|inbox)|verify your|verification|confirm your",
    re.I,
)


def classify_fields(fields):
    """Sort the visible boxes into email / password / name / etc."""
    found = {
        "emails": [], "passwords": [], "boxes": [],
        "first": None, "last": None, "username": None, "fullname": None,
    }
    for field in fields:
        kind, text = field["type"], field["text"]
        if kind == "password":
            found["passwords"].append(field)
        elif kind == "checkbox":
            found["boxes"].append(field)
        elif kind == "email" or "email" in text or "e-mail" in text:
            found["emails"].append(field)
        elif "first" in text or "given" in text:
            found["first"] = found["first"] or field
        elif "last" in text or "family" in text or "surname" in text:
            found["last"] = found["last"] or field
        elif "user" in text or "login" in text or "handle" in text:
            found["username"] = found["username"] or field
        elif "name" in text:
            found["fullname"] = found["fullname"] or field
    return found


def has_captcha(page):
    try:
        return page.locator(CAPTCHA_SELECTOR).count() > 0
    except Exception:
        return False


def settle(page):
    """Give the page a moment to finish loading."""
    try:
        page.wait_for_load_state("networkidle", timeout=5000)
    except Exception:
        pass
    page.wait_for_timeout(500)


def fill_generic_form(page, number, name, email, password, log):
    """Find the signup boxes on any page and fill them. Returns True/False."""
    fields = page.evaluate(FIELD_SCRIPT)
    found = classify_fields(fields)

    if not found["emails"] or not found["passwords"]:
        log(f"[{number}] Couldn't find an email and password box on this page.")
        return False

    def put(field, value):
        page.locator(f'[data-pl-idx="{field["idx"]}"]').fill(value, timeout=5000)

    parts = name.split(" ", 1)
    first_name = parts[0]
    last_name = parts[1] if len(parts) > 1 else parts[0]

    if found["fullname"]:
        log(f"[{number}] Filling name...")
        put(found["fullname"], name)
    if found["first"]:
        put(found["first"], first_name)
    if found["last"]:
        put(found["last"], last_name)
    if found["username"]:
        log(f"[{number}] Filling username...")
        put(found["username"], email.split("@")[0])

    log(f"[{number}] Filling email...")
    for field in found["emails"]:
        put(field, email)

    log(f"[{number}] Filling password...")
    for field in found["passwords"]:
        put(field, password)

    # Tick "I agree to the terms" style boxes
    for box in found["boxes"]:
        if re.search(r"terms|agree|accept|privacy|consent|policy", box["text"]):
            try:
                page.locator(f'[data-pl-idx="{box["idx"]}"]').check(
                    timeout=2000, force=True
                )
            except Exception:
                pass
    return True


def click_submit(page, number, log):
    """Click the Register / Sign up button (skips 'Sign up with Google' etc.)."""
    password_box = page.locator("input[type=password]:visible").first
    scope = page
    try:
        form = password_box.locator("xpath=ancestor::form")
        if form.count() > 0:
            scope = form.first
    except Exception:
        pass

    patterns = [
        r"sign\s*up|register|create.{0,12}account",
        r"join|get started|continue|next|submit",
    ]
    for pattern in patterns:
        buttons = scope.get_by_role("button", name=re.compile(pattern, re.I))
        for i in range(buttons.count()):
            button = buttons.nth(i)
            try:
                label = button.inner_text() or button.get_attribute("value") or ""
            except Exception:
                label = ""
            if SOCIAL_WORDS.search(label):
                continue
            log(f"[{number}] Clicking '{label.strip() or 'button'}'...")
            button.click(timeout=5000)
            return True

    log(f"[{number}] No button found, pressing Enter instead...")
    password_box.press("Enter")
    return True


def judge_result(page, number, log):
    """Look at the page after submitting and decide how it went."""
    try:
        page.wait_for_load_state("networkidle", timeout=6000)
    except Exception:
        pass
    page.wait_for_timeout(1000)

    if has_captcha(page):
        log(f"[{number}] A CAPTCHA showed up. Stopping - this tool doesn't solve those.")
        return "CAPTCHA"

    try:
        text = page.inner_text("body")
    except Exception:
        text = ""

    if ERROR_WORDS.search(text):
        log(f"[{number}] The site showed an error message.")
        return "FAIL"

    still_on_form = page.locator("input[type=password]:visible").count() > 0
    if not still_on_form:
        log(f"[{number}] The signup form is gone - looks like it worked.")
        return "PASS"
    if SUCCESS_WORDS.search(text):
        log(f"[{number}] The page shows a success message.")
        return "PASS"

    log(f"[{number}] Couldn't tell if it worked - check the browser.")
    return "CHECK"


def register_account(page, number, name, email, password, log, should_stop=None):
    """Do one full signup on the page that is already open."""
    stop = should_stop or (lambda: False)
    settle(page)
    if stop():
        return "STOPPED"

    if has_captcha(page):
        log(f"[{number}] CAPTCHA found on the page. Stopping - this tool doesn't solve those.")
        return "CAPTCHA"

    # Practice site has known field names, so use them when they exist.
    if page.get_by_test_id("input-fullname").count() > 0:
        log(f"[{number}] Practice site detected.")
        page.get_by_test_id("input-fullname").fill(name)
        page.get_by_test_id("input-email").fill(email)
        page.get_by_test_id("input-password").fill(password)
        if stop():
            return "STOPPED"
        if has_captcha(page):
            return "CAPTCHA"
        log(f"[{number}] Clicking Register...")
        # Prefer the practice site's exact button, but fall back to a visible
        # Register/Sign up control if the site's accessible role changes.
        button = page.get_by_role("button", name=re.compile(r"^register$", re.I))
        if button.count() == 0:
            button = page.locator('button, input[type="submit"]:visible').filter(
                has_text=re.compile(r"register|sign\s*up|create", re.I)
            )
        if button.count() == 0:
            raise RuntimeError("Register button was not found")
        button.first.click(timeout=5000)
    else:
        if not fill_generic_form(page, number, name, email, password, log):
            return "NO FORM"
        if stop():
            return "STOPPED"
        if has_captcha(page):
            log(f"[{number}] CAPTCHA appeared. Stopping - this tool doesn't solve those.")
            return "CAPTCHA"
        click_submit(page, number, log)

    return judge_result(page, number, log)


def normalize_url(raw):
    url = raw.strip()
    if not url:
        return None
    if not re.match(r"^https?://", url, re.I):
        local = re.match(
            r"^(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)",
            url,
            re.I,
        )
        url = ("http://" if local else "https://") + url
    return url


def make_password():
    return (
        "Test!"
        + "".join(random.choices(string.ascii_letters + string.digits, k=8))
        + random.choice(string.digits)
        + random.choice(string.ascii_lowercase)
    )


def parse_account_list(text):
    """Turn the notepad text into accounts.

    Each line is a name and an email, e.g.  Alex Smith, alex@mysite.com
    (a line with only an email also works). Returns (accounts, problems).
    """
    lines = [line.strip() for line in text.splitlines() if line.strip()]

    if len(lines) > MAX_ACCOUNTS:
        return [], [
            f"You entered {len(lines)} lines. The limit is {MAX_ACCOUNTS}."
        ]

    accounts, problems, seen = [], [], {}
    for number, line in enumerate(lines, start=1):
        match = EMAIL_FINDER.search(line)
        if not match:
            problems.append(f"Line {number}: no email address found.")
            continue

        email = match.group(0)
        key = email.lower()
        if key in seen:
            problems.append(
                f"Line {number}: same email as line {seen[key]}."
            )
            continue
        seen[key] = number

        rest = line.replace(email, " ")
        rest = re.sub(r"[,;\t]+", " ", rest).strip(" -:|")
        name = " ".join(rest.split()) or random.choice(FAKE_NAMES)
        accounts.append((name, email, make_password()))

    return accounts, problems


def short(error):
    lines = str(error).strip().splitlines()
    return (lines[0] if lines else "unknown error")[:200]


# ---------------------------------------------------------------------------
# The app window
# ---------------------------------------------------------------------------

class CheckBox(tk.Frame):
    """A dark-theme check box with a clear tick mark."""

    def __init__(self, parent, text, command=None, value=False):
        super().__init__(parent, bg=PANEL, cursor="hand2")
        self.value = bool(value)
        self.command = command

        self.box = tk.Canvas(
            self, width=18, height=18, bg=PANEL,
            highlightthickness=0, cursor="hand2"
        )
        self.box.pack(side="left")
        self.caption = tk.Label(
            self, text=text, bg=PANEL, fg=TEXT,
            font=(UI_FONT, 10), cursor="hand2"
        )
        self.caption.pack(side="left", padx=(8, 0))

        for widget in (self, self.box, self.caption):
            widget.bind("<Button-1>", self.toggle)
        self.draw()

    def draw(self):
        self.box.delete("all")
        if self.value:
            self.box.create_rectangle(
                1, 1, 17, 17, fill=GREEN_FILL, outline=GREEN_FILL
            )
            self.box.create_line(4, 9, 8, 13, 14, 5, fill="white", width=2)
        else:
            self.box.create_rectangle(
                1, 1, 17, 17, fill=INPUT_BG, outline=BORDER_LIGHT
            )

    def toggle(self, _event=None):
        self.set(not self.value)
        if self.command:
            self.command()

    def set(self, value):
        self.value = bool(value)
        self.draw()

    def get(self):
        return self.value


class HydraLinkServer:
    """Small authenticated LAN control server for the Hydra Link companion app."""
    def __init__(self, app, port=HYDRA_LINK_PORT):
        self.app = app
        self.port = port
        self.token = ''.join(random.choices(string.ascii_letters + string.digits, k=32))
        self.pair_code = ''.join(random.choices(string.digits, k=6))
        self.server = None
        self.thread = None

    def local_ip(self):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.connect(("8.8.8.8", 80))
            ip = sock.getsockname()[0]
            sock.close()
            return ip
        except Exception:
            return "127.0.0.1"

    def start(self):
        app = self.app
        token = self.token
        pair_code = self.pair_code
        mobile_html = MOBILE_HTML

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_args):
                return

            def authorized(self):
                parsed = urlparse(self.path)
                qs = parse_qs(parsed.query)
                return qs.get("token", [""])[0] == token or self.headers.get("X-Hydra-Token", "") == token

            def send_json(self, payload, status=200):
                data = json.dumps(payload).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def do_GET(self):
                parsed = urlparse(self.path)
                if parsed.path == "/mobile":
                    data = mobile_html.encode("utf-8")
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("Content-Length", str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                    return
                if parsed.path == "/api/pair":
                    qs = parse_qs(parsed.query)
                    if qs.get("code", [""])[0] != pair_code:
                        self.send_json({"error":"invalid pairing code"}, 401); return
                    self.send_json({"ok":True,"token":token,"mobile":"/mobile"})
                    return
                if parsed.path == "/api/status":
                    if not self.authorized():
                        self.send_json({"error":"unauthorized"}, 401); return
                    self.send_json(app.link_snapshot())
                    return
                if parsed.path == "/":
                    if not self.authorized():
                        self.send_json({"name":"Hydra Link","pair_required":True}, 401); return
                    self.send_json({"name":"Hydra Link","mobile":"/mobile","status":app.link_snapshot()})
                    return
                self.send_json({"error":"not found"}, 404)

            def do_POST(self):
                parsed = urlparse(self.path)
                if not self.authorized():
                    self.send_json({"error":"unauthorized"}, 401); return
                if parsed.path != "/api/command":
                    self.send_json({"error":"not found"}, 404); return
                try:
                    length = int(self.headers.get("Content-Length", "0"))
                    body = json.loads(self.rfile.read(length) or b"{}")
                except Exception:
                    self.send_json({"error":"bad json"}, 400); return
                command = body.get("command")
                allowed = {"generate", "start", "stop", "close"}
                if command not in allowed:
                    self.send_json({"error":"unsupported command"}, 400); return
                app.ui(app.handle_link_command, command)
                self.send_json({"ok":True,"command":command})

        try:
            self.server = ThreadingHTTPServer(("0.0.0.0", self.port), Handler)
        except OSError:
            self.server = ThreadingHTTPServer(("0.0.0.0", 0), Handler)
        self.port = self.server.server_address[1]
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        return self.local_ip(), self.port, self.pair_code

    def stop(self):
        if self.server:
            try:
                self.server.shutdown()
                self.server.server_close()
            except Exception:
                pass
            self.server = None


MOBILE_HTML = r'''<!doctype html>
<html><head><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#0f1318"><title>Hydra Link</title>
<style>*{box-sizing:border-box}body{margin:0;background:#0f1318;color:#e4e8ee;font-family:system-ui,-apple-system,Segoe UI,sans-serif;padding:20px;max-width:720px;margin:auto}.card{background:#171c23;border:1px solid #2a323d;border-radius:16px;padding:18px;margin:12px 0}.muted{color:#8a94a3;font-size:13px}.status{font-size:22px;font-weight:700}.dot{display:inline-block;width:10px;height:10px;border-radius:50%;background:#5fd39a;margin-right:8px}.input{width:100%;padding:13px;border-radius:10px;border:1px solid #3a4453;background:#11161c;color:#e4e8ee;margin:6px 0}.btn{width:100%;padding:15px;border:0;border-radius:12px;margin-top:10px;font-size:16px;font-weight:700;background:#2a9d6f;color:white}.danger{background:#2b1f24;color:#e57373;border:1px solid #6b3a40}.small{font-size:13px}</style></head>
<body><h1>Hydra Link</h1><div class="muted">Remote control for your paired Hydra desktop.</div>
<div id="pair" class="card"><b>Pair this phone</b><input id="host" class="input" placeholder="Desktop address, e.g. http://192.168.1.5:8765"><input id="code" class="input" inputmode="numeric" maxlength="6" placeholder="6-digit pairing code"><button class="btn" onclick="pair()">PAIR</button><div id="pairmsg" class="small muted"></div></div>
<div id="app" style="display:none"><div class="card"><div class="status"><span class="dot"></span><span id="status">Connecting...</span></div><div id="details" class="small muted" style="margin-top:8px"></div></div><div class="card"><button class="btn" onclick="cmd('generate')">GENERATE</button><button class="btn" onclick="cmd('start')">START TEST</button><button class="btn" onclick="cmd('stop')">STOP</button><button class="btn danger" onclick="cmd('close')">CLOSE BROWSER</button><div id="msg" class="small muted" style="margin-top:10px"></div></div></div>
<script>
let host=localStorage.getItem('hydra_host')||location.origin, token=localStorage.getItem('hydra_token')||'';
if(token){document.getElementById('pair').style.display='none';document.getElementById('app').style.display='block';status();} else if(location.origin!=='null' && location.origin!=='file://') document.getElementById('host').value=location.origin;
async function pair(){host=document.getElementById('host').value.trim().replace(/\/$/,'');let code=document.getElementById('code').value.trim();try{let r=await fetch(host+'/api/pair?code='+encodeURIComponent(code));let x=await r.json();if(!x.ok)throw new Error(x.error||'Pairing failed');token=x.token;localStorage.setItem('hydra_host',host);localStorage.setItem('hydra_token',token);document.getElementById('pair').style.display='none';document.getElementById('app').style.display='block';status();}catch(e){document.getElementById('pairmsg').textContent=e.message||'Could not connect.';}}
async function status(){try{let r=await fetch(host+'/api/status?token='+encodeURIComponent(token));if(!r.ok)throw 0;let s=await r.json();document.getElementById('status').textContent=s.status||'READY';document.getElementById('details').innerHTML='Running: '+s.running+'<br>Records: '+s.records+'<br>Browser: '+s.browser+'<br>Pair code: '+s.pair_code;}catch(e){document.getElementById('status').textContent='Disconnected';}}
async function cmd(c){try{let r=await fetch(host+'/api/command?token='+encodeURIComponent(token),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({command:c})});let x=await r.json();document.getElementById('msg').textContent=x.ok?'Command sent: '+c:(x.error||'Error');setTimeout(status,300);}catch(e){document.getElementById('msg').textContent='Could not reach Hydra.';}}setInterval(status,1000);
</script></body></html>'''


class AutomationApp:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_NAME)
        self.root.geometry("1000x780")
        self.root.minsize(1000, 700)
        self.root.configure(bg=BG)

        self.rows = []
        self.running = False
        self.test_mode = True
        self.permission_ok = False
        self.current_page = None
        self.close_requested = threading.Event()
        self.stop_requested = threading.Event()
        self.ui_queue = queue.Queue()
        self.link_server = HydraLinkServer(self)
        self.link_ip, self.link_port, self.link_pair_code = self.link_server.start()

        self.setup_styles()

        self.outer = tk.Frame(root, bg=BG)
        self.outer.pack(fill="both", expand=True, padx=16, pady=(14, 10))

        # Order matters: top panels first, bottom panels next, table fills the rest.
        self.build_header()
        self.build_config()
        self.build_toolbar()
        self.build_footer()
        self.build_log()
        self.build_table()

        self.log_message("System online.")
        self.log_message("Test mode is on: fake @example.test addresses only.")
        self.log_message("Max 10 accounts per run.")
        self.log_message(f"Hydra Link ready: http://{self.link_ip}:{self.link_port}/mobile")
        self.log_message(f"Hydra Link pairing code: {self.link_pair_code}")
        self.log_message("Tick the permission box, then GENERATE and START TEST.")
        self.update_test_mode_ui()
        self.show_status("READY")

        self.root.after(100, self.process_queue)

    # ----- building blocks -----

    def setup_styles(self):
        try:
            style = ttk.Style()
            style.theme_use("clam")
            style.configure(
                "Dark.Vertical.TScrollbar",
                background=BORDER_LIGHT, troughcolor=PANEL,
                bordercolor=PANEL, lightcolor=BORDER_LIGHT,
                darkcolor=BORDER_LIGHT, arrowcolor=MUTED, relief="flat"
            )
            style.map(
                "Dark.Vertical.TScrollbar",
                background=[("active", MUTED)]
            )
        except Exception:
            pass

    def make_panel(self, side="top", fill="x", expand=False, pady=(0, 10)):
        shell = tk.Frame(
            self.outer, bg=PANEL, highlightthickness=1,
            highlightbackground=BORDER, highlightcolor=BORDER
        )
        shell.pack(side=side, fill=fill, expand=expand, pady=pady)
        inner = tk.Frame(shell, bg=PANEL)
        inner.pack(fill="both", expand=True, padx=14, pady=12)
        return inner

    def section_title(self, parent, text, hint=""):
        row = tk.Frame(parent, bg=PANEL)
        row.pack(fill="x")
        tk.Label(
            row, text=text, bg=PANEL, fg=MUTED, font=(UI_FONT, 9, "bold")
        ).pack(side="left")
        if hint:
            tk.Label(
                row, text=hint, bg=PANEL, fg=MUTED, font=(UI_FONT, 9)
            ).pack(side="left", padx=10)
        return row

    def make_button(self, parent, text, command, kind="secondary", small=False):
        styles = {
            "primary": ("#ffffff", GREEN_FILL, GREEN_HOVER, GREEN_FILL),
            "secondary": (TEXT, BTN_BG, BTN_HOVER, BORDER_LIGHT),
            "danger": (RED, PANEL, RED_HOVER, RED_BORDER),
        }
        fg, bg, hover, border = styles[kind]
        button = tk.Button(
            parent, text=text, command=command,
            fg=fg, bg=bg, activeforeground=fg, activebackground=hover,
            relief="flat", bd=0, cursor="hand2",
            highlightthickness=1, highlightbackground=border,
            highlightcolor=border,
            font=(UI_FONT, 8 if small else 9, "bold"),
            padx=10 if small else 12, pady=3 if small else 6
        )
        button.bind("<Enter>", lambda _e: button.config(bg=hover))
        button.bind("<Leave>", lambda _e: button.config(bg=bg))
        return button

    def make_entry(self, parent, variable):
        return tk.Entry(
            parent, textvariable=variable,
            fg=TEXT, bg=INPUT_BG, insertbackground=TEXT,
            relief="flat", bd=8, font=(MONO_FONT, 10),
            highlightthickness=1, highlightbackground=BORDER_LIGHT,
            highlightcolor=ACCENT_BLUE
        )

    def divider(self, parent):
        tk.Frame(parent, bg=BORDER, width=1, height=26).pack(
            side="left", padx=10
        )

    # ----- the five sections -----

    def build_header(self):
        inner = self.make_panel()

        titles = tk.Frame(inner, bg=PANEL)
        titles.pack(side="left")
        tk.Label(
            titles, text=APP_NAME, bg=PANEL, fg=TEXT,
            font=(UI_FONT, 18, "bold")
        ).pack(anchor="w")
        tk.Label(
            titles,
            text="Account automation workspace  -  for sites you own or have permission to test",
            bg=PANEL, fg=MUTED, font=(UI_FONT, 9)
        ).pack(anchor="w")

        self.badge = tk.Frame(
            inner, bg=INPUT_BG, highlightthickness=1,
            highlightbackground=BORDER_LIGHT
        )
        self.badge.pack(side="right", anchor="n")
        self.badge_dot = tk.Label(
            self.badge, text="\u25cf", bg=INPUT_BG, fg=MUTED,
            font=(UI_FONT, 10)
        )
        self.badge_dot.pack(side="left", padx=(10, 4), pady=4)
        self.badge_text = tk.Label(
            self.badge, text="READY", bg=INPUT_BG, fg=TEXT,
            font=(UI_FONT, 9, "bold")
        )
        self.badge_text.pack(side="left", padx=(0, 12), pady=4)

    def build_config(self):
        inner = self.make_panel()
        self.section_title(inner, "CONFIGURATION")

        tk.Label(
            inner, text="Target site address", bg=PANEL, fg=TEXT,
            font=(UI_FONT, 10)
        ).pack(anchor="w", pady=(10, 4))
        self.site = tk.StringVar(value=DEFAULT_URL)
        self.make_entry(inner, self.site).pack(fill="x", ipady=3)

        options = tk.Frame(inner, bg=PANEL)
        options.pack(fill="x", pady=(14, 0))
        self.test_check = CheckBox(
            options, "Test mode  (fake @example.test addresses only)",
            command=self.on_test_mode_toggled, value=True
        )
        self.test_check.pack(side="left")
        self.permission_check = CheckBox(
            options, "I own this site or have permission to test it",
            command=self.on_permission_toggled
        )
        self.permission_check.pack(side="left", padx=(32, 0))

        self.auto_navigate_check = CheckBox(
            options, "Automatic page navigation",
            value=True
        )
        self.auto_navigate_check.pack(side="left", padx=(32, 0))

        # Your list (only shown when test mode is off)
        self.list_frame = tk.Frame(inner, bg=PANEL)

        list_header = tk.Frame(self.list_frame, bg=PANEL)
        list_header.pack(fill="x", pady=(0, 6))
        tk.Label(
            list_header, text="Your list", bg=PANEL, fg=TEXT,
            font=(UI_FONT, 10, "bold")
        ).pack(side="left")
        tk.Label(
            list_header, text="one per line:  Name, email   (max 10)",
            bg=PANEL, fg=MUTED, font=(UI_FONT, 9)
        ).pack(side="left", padx=10)
        self.make_button(
            list_header, "CLEAR LIST", self.clear_list, "danger", small=True
        ).pack(side="right")
        self.make_button(
            list_header, "LOAD FROM FILE", self.load_list_file,
            "secondary", small=True
        ).pack(side="right", padx=6)

        list_wrap = tk.Frame(
            self.list_frame, bg=INPUT_BG, highlightthickness=1,
            highlightbackground=BORDER_LIGHT
        )
        list_wrap.pack(fill="x")
        self.list_box = tk.Text(
            list_wrap, height=5, bg=INPUT_BG, fg=TEXT,
            insertbackground=TEXT, relief="flat", bd=0,
            padx=10, pady=8, font=(MONO_FONT, 10), wrap="none",
            highlightthickness=0
        )
        list_scroll = ttk.Scrollbar(
            list_wrap, orient="vertical", command=self.list_box.yview,
            style="Dark.Vertical.TScrollbar"
        )
        self.list_box.config(yscrollcommand=list_scroll.set)
        list_scroll.pack(side="right", fill="y")
        self.list_box.pack(side="left", fill="x", expand=True)
        self.list_box.bind(
            "<FocusIn>",
            lambda _e: list_wrap.config(highlightbackground=ACCENT_BLUE)
        )
        self.list_box.bind(
            "<FocusOut>",
            lambda _e: list_wrap.config(highlightbackground=BORDER_LIGHT)
        )

    def build_toolbar(self):
        inner = self.make_panel()

        left = tk.Frame(inner, bg=PANEL)
        left.pack(side="left")

        tk.Label(
            left, text="Test users", bg=PANEL, fg=MUTED,
            font=(UI_FONT, 9)
        ).pack(side="left", padx=(0, 8))
        self.amount = tk.IntVar(value=1)
        self.spinbox = tk.Spinbox(
            left, from_=1, to=MAX_ACCOUNTS, textvariable=self.amount,
            width=4, justify="center", fg=TEXT, bg=INPUT_BG,
            insertbackground=TEXT, buttonbackground=BTN_BG,
            disabledbackground=PANEL, disabledforeground=MUTED,
            relief="flat", font=(MONO_FONT, 10),
            highlightthickness=1, highlightbackground=BORDER_LIGHT,
            highlightcolor=ACCENT_BLUE
        )
        self.spinbox.pack(side="left", ipady=4, padx=(0, 8))

        self.make_button(left, "GENERATE", self.generate).pack(side="left", padx=3)
        self.make_button(
            left, "START TEST", self.start_test, "primary"
        ).pack(side="left", padx=3)

        self.divider(left)

        self.make_button(
            left, "CLOSE BROWSER", self.close_browser
        ).pack(side="left", padx=3)
        self.make_button(
            left, "SAVE RESULTS", self.save_results
        ).pack(side="left", padx=3)

        link = tk.Frame(inner, bg=PANEL)
        link.pack(side="left", padx=(18, 0))
        tk.Label(link, text="PHONE", bg=PANEL, fg=MUTED, font=(UI_FONT, 8, "bold")).pack(anchor="w")
        tk.Label(link, text=f"Hydra Link  {self.link_ip}:{self.link_port}", bg=PANEL, fg=BLUE_INFO, font=(MONO_FONT, 8)).pack(anchor="w")
        tk.Label(link, text=f"Code {self.link_pair_code}", bg=PANEL, fg=MUTED, font=(MONO_FONT, 8)).pack(anchor="w")

        right = tk.Frame(inner, bg=PANEL)
        right.pack(side="right")
        self.make_button(
            right, "DELETE SAVED", self.delete_saved, "danger"
        ).pack(side="right", padx=3)
        self.make_button(right, "CLEAR", self.clear, "danger").pack(side="right", padx=3)
        self.make_button(right, "STOP", self.stop_test, "danger").pack(side="right", padx=3)

    def build_table(self):
        inner = self.make_panel(fill="both", expand=True)
        self.section_title(inner, "RESULTS")

        self.table = tk.Frame(inner, bg=PANEL)
        self.table.pack(fill="both", expand=True, pady=(8, 0))

        headers = ["#", "NAME", "EMAIL", "PASSWORD", "RESULT"]
        sizes = [(0, 46), (2, 150), (3, 220), (2, 150), (1, 120)]
        for column, header in enumerate(headers):
            weight, minsize = sizes[column]
            self.table.columnconfigure(column, weight=weight, minsize=minsize)
            tk.Label(
                self.table, text=header, bg=HEADER_BG, fg=MUTED,
                font=(UI_FONT, 8, "bold"), anchor="w", padx=10, pady=8
            ).grid(row=0, column=column, sticky="ew")

        tk.Frame(self.table, bg=BORDER, height=1).grid(
            row=1, column=0, columnspan=5, sticky="ew"
        )

        self.empty_label = tk.Label(
            self.table,
            text="No accounts yet. Click GENERATE to build the list.",
            bg=PANEL, fg=MUTED, font=(UI_FONT, 10), pady=22
        )
        self.empty_label.grid(row=2, column=0, columnspan=5, sticky="ew")

    def build_log(self):
        inner = self.make_panel(side="bottom", pady=(0, 0))
        self.section_title(inner, "SYSTEM LOG")

        wrap = tk.Frame(inner, bg=LOG_BG, highlightthickness=1, highlightbackground=BORDER)
        wrap.pack(fill="x", pady=(8, 0))
        self.log = tk.Text(
            wrap, height=8, bg=LOG_BG, fg="#9aa8ba",
            relief="flat", bd=0, padx=10, pady=8,
            font=(MONO_FONT, 9), wrap="word", state="disabled",
            highlightthickness=0
        )
        scroll = ttk.Scrollbar(
            wrap, orient="vertical", command=self.log.yview,
            style="Dark.Vertical.TScrollbar"
        )
        self.log.config(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.log.pack(side="left", fill="both", expand=True)

        self.log.tag_config("time", foreground="#566172")
        self.log.tag_config("info", foreground="#9aa8ba")
        self.log.tag_config("warn", foreground=AMBER)
        self.log.tag_config("err", foreground=RED)
        self.log.tag_config("ok", foreground=GREEN_TEXT)

    def build_footer(self):
        footer = tk.Frame(self.outer, bg=BG)
        footer.pack(side="bottom", fill="x", pady=(10, 0))
        tk.Label(
            footer, text=f"{APP_NAME}  v{APP_VERSION}", bg=BG, fg=MUTED,
            font=(UI_FONT, 9)
        ).pack(side="left")
        tk.Label(
            footer, text=f"Lead Developer:  {LEAD_DEVELOPER}", bg=BG, fg=MUTED,
            font=(UI_FONT, 9)
        ).pack(side="right")

    # ----- switches -----

    def on_permission_toggled(self):
        self.permission_ok = self.permission_check.get()

    def on_test_mode_toggled(self):
        if self.running:
            self.test_check.set(self.test_mode)
            self.log_message("A test is running. Wait for it to finish first.")
            return
        self.test_mode = self.test_check.get()
        self.clear_rows_only()
        self.show_status("READY")
        self.update_test_mode_ui()
        if self.test_mode:
            self.log_message("Test mode on: fake @example.test addresses only.")
        else:
            self.log_message("Test mode off: type your own list, then GENERATE.")

    def update_test_mode_ui(self):
        if self.test_mode:
            self.list_frame.pack_forget()
            self.spinbox.config(state="normal")
            self.root.geometry("1000x780")
        else:
            self.list_frame.pack(fill="x", pady=(14, 0))
            self.spinbox.config(state="disabled")
            self.root.geometry("1000x920")

    # ----- safe way for the background thread to update the window -----

    def ui(self, func, *args):
        self.ui_queue.put((func, args))

    def process_queue(self):
        try:
            while True:
                func, args = self.ui_queue.get_nowait()
                func(*args)
        except queue.Empty:
            pass
        self.root.after(100, self.process_queue)

    def log_message(self, message):
        self.ui(self._write_log, message)

    def _write_log(self, message):
        level = classify_log(message)
        self.log.config(state="normal")
        self.log.insert("end", time.strftime("%H:%M:%S") + "  ", "time")
        self.log.insert("end", message + "\n", level)
        self.log.see("end")
        self.log.config(state="disabled")

    def set_status(self, text):
        self.ui(self.show_status, text)

    def show_status(self, text):
        text = text.replace("STATUS:", "").strip()
        self.badge_dot.config(fg=status_color(text))
        self.badge_text.config(text=text)

    def set_result(self, index, text):
        def apply():
            try:
                apply_badge(self.rows[index]["labels"][4], text)
            except IndexError:
                pass

        self.ui(apply)

    # ----- test data -----

    def fake_account(self, number):
        name = random.choice(FAKE_NAMES)
        email = f"test_{number}_{random.randint(1000, 9999)}@{TEST_DOMAIN}"
        return name, email, make_password()

    def generate(self):
        if self.running:
            self.log_message("A test is running. Wait for it to finish first.")
            return

        if self.test_mode:
            try:
                amount = max(1, min(MAX_ACCOUNTS, int(self.amount.get())))
            except (ValueError, tk.TclError):
                amount = 1
            accounts = [self.fake_account(n) for n in range(1, amount + 1)]
        else:
            accounts, problems = parse_account_list(
                self.list_box.get("1.0", "end")
            )
            if problems:
                for problem in problems:
                    self.log_message(problem)
                messagebox.showinfo("Check your list", "\n".join(problems[:8]))
                return
            if not accounts:
                messagebox.showinfo(
                    "Nothing entered",
                    "Type at least one line like:  Alex Smith, alex@yoursite.com"
                )
                return

        self.clear_rows_only()

        for number, (name, email, password) in enumerate(accounts, start=1):
            bg = PANEL if number % 2 else PANEL_ALT
            grid_row = number + 1
            labels, widgets = [], []

            for column, value in enumerate([str(number), name, email, password]):
                label = tk.Label(
                    self.table, text=value, bg=bg,
                    fg=MUTED if column == 0 else TEXT,
                    font=(MONO_FONT, 10), anchor="w", padx=10, pady=7
                )
                label.grid(row=grid_row, column=column, sticky="ew")
                labels.append(label)
                widgets.append(label)

            cell = tk.Frame(self.table, bg=bg)
            cell.grid(row=grid_row, column=4, sticky="nsew")
            badge = tk.Label(cell, font=(UI_FONT, 8, "bold"), padx=10, pady=2)
            badge.pack(anchor="w", padx=10, pady=6)
            apply_badge(badge, "READY")
            labels.append(badge)
            widgets.append(cell)

            self.rows.append({
                "name": name, "email": email, "password": password,
                "labels": labels, "widgets": widgets
            })

        self.refresh_placeholder()
        count = len(accounts)
        source = "fake data" if self.test_mode else "your list"
        self.show_status(f"{count} RECORD(S) READY")
        self.log_message(f"Built {count} record(s) from {source}.")

    def clear_rows_only(self):
        for row in self.rows:
            for widget in row["widgets"]:
                widget.destroy()
        self.rows.clear()
        self.refresh_placeholder()

    def refresh_placeholder(self):
        if self.rows:
            self.empty_label.grid_remove()
        else:
            self.empty_label.grid()

    def clear(self):
        if self.running:
            self.log_message("A test is running. Wait for it to finish first.")
            return
        self.clear_rows_only()
        self.show_status("READY")
        self.log_message("Cleared test records.")

    # ----- running the test -----

    def start_test(self):
        if self.running:
            self.log_message("A test is already running.")
            return

        if not self.rows:
            messagebox.showinfo("Nothing to test", "Click GENERATE first.")
            return

        if not self.permission_ok:
            self.show_status("TICK THE PERMISSION BOX FIRST")
            self.log_message("Blocked: tick the permission box before starting.")
            messagebox.showinfo(
                "Permission needed",
                "Tick the box confirming you own this site or have "
                "permission to test it."
            )
            return

        url = normalize_url(self.site.get())
        if not url:
            messagebox.showinfo("Site address", "Type the site address first.")
            return

        if len(self.rows) > MAX_ACCOUNTS:
            self.log_message(f"The limit is {MAX_ACCOUNTS} accounts per run.")
            return

        accounts = [(r["name"], r["email"], r["password"]) for r in self.rows]

        for index in range(len(accounts)):
            self.set_result(index, "READY")

        self.running = True
        self.close_requested.clear()
        self.stop_requested.clear()
        self.current_page = None
        self.show_status("STARTING BROWSER...")

        threading.Thread(
            target=self.run_browser, args=(url, accounts), daemon=True
        ).start()

    def link_snapshot(self):
        browser_open = False
        try:
            browser_open = self.current_page is not None and not self.current_page.is_closed()
        except Exception:
            browser_open = False
        return {
            "status": self.badge_text.cget("text") if hasattr(self, "badge_text") else "STARTING",
            "running": bool(self.running),
            "records": len(self.rows),
            "browser": "open" if browser_open else "closed",
            "pair_code": self.link_pair_code,
        }

    def handle_link_command(self, command):
        if command == "generate":
            self.generate()
        elif command == "start":
            self.start_test()
        elif command == "stop":
            self.stop_test()
        elif command == "close":
            self.close_browser()

    def stop_test(self):
        if not self.running:
            self.log_message("Nothing is running.")
            return
        self.stop_requested.set()
        self.log_message("Stopping... the browser will stay open.")

    def should_stop(self):
        return self.stop_requested.is_set() or self.close_requested.is_set()

    def skip_rest(self, start_index, total):
        for i in range(start_index, total):
            self.set_result(i, "SKIPPED")

    def save_screenshot(self, page, number, result):
        try:
            os.makedirs(SCREENSHOT_DIR, exist_ok=True)
            stamp = time.strftime("%Y%m%d-%H%M%S")
            label = result.replace(" ", "_")
            filename = f"account{number}_{label}_{stamp}.png"
            page.screenshot(
                path=os.path.join(SCREENSHOT_DIR, filename),
                full_page=True, timeout=10000
            )
            self.log_message(f"[{number}] Saved a picture: screenshots\\" + filename)
        except Exception:
            self.log_message(f"[{number}] Couldn't take a picture of the page.")

    # ----- files -----

    def save_results(self):
        if not self.rows:
            messagebox.showinfo("Nothing to save", "Click GENERATE first.")
            return
        os.makedirs(RESULTS_DIR, exist_ok=True)
        path = filedialog.asksaveasfilename(
            title="Save results",
            initialdir=RESULTS_DIR,
            defaultextension=".csv",
            initialfile="results_" + time.strftime("%Y%m%d-%H%M%S") + ".csv",
            filetypes=[("CSV (opens in Excel)", "*.csv"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as handle:
                writer = csv.writer(handle)
                writer.writerow(["#", "Name", "Email", "Password", "Result"])
                for number, row in enumerate(self.rows, start=1):
                    writer.writerow([
                        number, row["name"], row["email"], row["password"],
                        row["labels"][4].cget("text")
                    ])
            self.log_message("Saved results to " + path)
        except OSError as error:
            messagebox.showerror("Couldn't save", short(error))

    def delete_saved(self):
        if self.running:
            self.log_message("A test is running. Wait for it to finish first.")
            return
        files = list_saved_files()
        if not files:
            messagebox.showinfo(
                "Nothing to delete",
                "There are no saved results or screenshots yet."
            )
            return
        sure = messagebox.askyesno(
            "Delete saved results",
            f"Delete {len(files)} saved file(s)?\n\n"
            "This removes the pictures in the 'screenshots' folder and the "
            "result files in the 'results' folder next to the app. "
            "It can't be undone."
        )
        if not sure:
            return
        deleted = 0
        for path in files:
            try:
                os.remove(path)
                deleted += 1
            except OSError:
                pass
        self.log_message(f"Deleted {deleted} saved file(s).")
        if deleted < len(files):
            self.log_message(
                f"Couldn't delete {len(files) - deleted} file(s). "
                "They may be open in another program."
            )

    def load_list_file(self):
        path = filedialog.askopenfilename(
            title="Open your list",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8-sig", errors="replace") as handle:
                text = handle.read(20000)
        except OSError as error:
            messagebox.showerror("Couldn't open file", short(error))
            return
        self.list_box.delete("1.0", "end")
        self.list_box.insert("1.0", text)
        count = len([line for line in text.splitlines() if line.strip()])
        self.log_message(f"Loaded {count} line(s) from {os.path.basename(path)}.")
        if count > MAX_ACCOUNTS:
            self.log_message(
                f"Heads up: the limit is {MAX_ACCOUNTS}. Trim the list before GENERATE."
            )

    def clear_list(self):
        self.list_box.delete("1.0", "end")
        self.log_message("Notepad cleared.")

    def close_browser(self):
        if not self.running:
            self.log_message("No browser is open.")
            return
        self.close_requested.set()
        self.log_message("Closing browser...")

    # ----- the browser run (background thread) -----

    def run_browser(self, url, accounts):
        try:
            with sync_playwright() as playwright:
                self.log_message("Launching browser...")
                browser = launch_browser(playwright, self.log_message)

                try:
                    self.run_accounts(browser, url, accounts)
                except Exception as error:
                    self.log_message("ERROR: " + short(error))
                    self.set_status("ERROR - BROWSER LEFT OPEN")

                # The browser stays open until you close it.
                self.hold_open(browser)

                try:
                    browser.close()
                except Exception:
                    pass

            self.log_message("Browser closed.")
            self.set_status("BROWSER CLOSED")

        except Exception as error:
            self.set_status("ERROR")
            self.log_message("ERROR: " + short(error))
            self.ui(messagebox.showerror, "Automation Error", short(error))

        finally:
            self.running = False

    def wait_for_manual_navigation(self, page, target_url, number):
        """Wait until the user manually navigates the open browser page."""
        self.set_status(f"ACCOUNT {number}: WAITING FOR MANUAL NAVIGATION")
        while not self.should_stop():
            try:
                current_url = page.url
                if current_url and current_url not in ("about:blank", "chrome://newtab/", "edge://newtab/"):
                    self.log_message(f"[{number}] Manual navigation detected: {current_url}")
                    return True
            except Exception:
                return False
            time.sleep(0.25)
        return False

    def run_accounts(self, browser, url, accounts):
        previous = None
        total = len(accounts)

        for index, (name, email, password) in enumerate(accounts):
            if self.should_stop():
                self.skip_rest(index, total)
                self.log_message("Stopped. Browser stays open.")
                self.set_status("STOPPED - BROWSER STAYS OPEN")
                return

            number = index + 1
            self.set_result(index, "RUNNING")
            self.set_status(f"ACCOUNT {number} OF {total}")

            context = browser.new_context()
            page = context.new_page()
            self.current_page = page

            # Close the previous account's window now that the new one is up
            if previous is not None:
                try:
                    previous.close()
                except Exception:
                    pass
            previous = context

            self.log_message(f"[{number}] Opening browser page")
            try:
                if self.auto_navigate_check.get():
                    self.log_message(f"[{number}] Navigating automatically to {url}")
                    page.goto(url, wait_until="domcontentloaded", timeout=30000)
                else:
                    self.log_message(
                        f"[{number}] Automatic navigation is OFF. "
                        f"Navigate manually to {url} in the open browser."
                    )
                    if not self.wait_for_manual_navigation(page, url, number):
                        result = "STOPPED"
                        self.set_result(index, result)
                        self.skip_rest(index + 1, total)
                        return

                result = register_account(
                    page, number, name, email, password,
                    self.log_message, self.should_stop
                )
            except Exception as error:
                self.log_message(f"[{number}] Problem: " + short(error))
                result = "FAIL"

            self.set_result(index, result)

            if result == "STOPPED":
                self.skip_rest(index + 1, total)
                self.log_message("Stopped. Browser stays open.")
                self.set_status("STOPPED - BROWSER STAYS OPEN")
                return

            if result != "PASS":
                self.save_screenshot(page, number, result)
                self.skip_rest(index + 1, total)
                self.log_message(
                    "Stopped here. Browser left open so you can take a look."
                )
                self.set_status(f"STOPPED AT ACCOUNT {number} ({result})")
                return

            page.wait_for_timeout(1000)

        self.set_status("ALL DONE - BROWSER STAYS OPEN")
        self.log_message("ALL DONE.")

    def hold_open(self, browser):
        self.log_message(
            "Browser stays open. Close its window or press CLOSE BROWSER when done."
        )
        while not self.close_requested.is_set():
            page = self.current_page
            if page is None:
                break
            try:
                if page.is_closed():
                    break
                page.wait_for_timeout(500)
            except Exception:
                break


if __name__ == "__main__":
    window = tk.Tk()
    AutomationApp(window)
    try:
        window.mainloop()
    finally:
        try:
            window.link_server.stop()
        except Exception:
            pass
